more "./ProteinEvolverProtABC_arguments.txt" | xargs -n 35 "./bin/ProteinEvolverProtABC1.2.0"
