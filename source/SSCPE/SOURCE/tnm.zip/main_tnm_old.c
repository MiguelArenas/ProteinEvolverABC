#define PRG "tnm"


/********** Parameters not set from input file *************/
// Fit of B factors
float R_MIN=0.00;     // Minimum correlation above which B-factors are fitted
float SLOPE_MIN=0.00; // Minimum slope above which B-factors are fitted
float s0=0.07;       // Entropy per residue

int SWITCH_BONDS=1; // Bonds with all atoms (0) or only aligned atoms (1)?

// Default parameters
// Model parameters
#define REF_DEF "ALL"      // Ref. atoms Allowed: CA BB(backbone) EB ALL
#define INT_TYPE_DEF "MIN" // Interaction type. Allowed: CA CB ALL MIN
#define THR_CA 9.0         // For CA contacts
#define THR_CB 9.0         // For CB contacts
#define THR_ALL 5.0        // For ALL and MIN atoms contacts
#define EXP_HESSIAN_DEF 6  // force constant ~ r^(-EXP_HESSIAN)
#define K_OMEGA_DEF 0.3      // Force constant for omega torsions
#define K_PSI_DEF 0.1      // Force constant for psi torsions
#define K_PHI_DEF 0.1      // Force constant for phi torsions
#define K_CHI_DEF 0.3      // Force constant for chi torsions
#define K_BA_DEF 0.2       // Force constant for bond angles
#define K_BL_DEF 0.5       // Force constant for bond length
#define MIN_INT_DEF 1      // Freeze unconstrained degrees of freedom

int FIT_B=1;          // Fit B factors if present?
float KAPPA=218.4;    // Force constant for default parameters C=4.5 E=6
#define COLL_THR_DEF 30   
float COLL_THR= COLL_THR_DEF;  // Select mode if exp(-S_cart) > COLL_THR

// Elastic constants
float K_OMEGA=K_OMEGA_DEF, K_PSI=K_PSI_DEF, K_PHI=K_PHI_DEF,
  K_CHI=K_CHI_DEF, K_BA=K_BA_DEF, K_BL=K_BL_DEF;

// Output
#define PRINT_PDB_DEF 1
#define PRINT_MODE_SUMM_DEF 1
#define PRINT_FORCE_DEF 0
#define PDB_STEP_DEF  0.4  // Step for printing PDB

// Analysis of conformation change
int MIN_ALI_LEN_DEF=20; // Chains are aligned if L>MIN_ALI_LEN, if not peptides
float RMSD_MAX=100;   // max. RMSD for analyzing conformation change
float RMSD_MIN=0.5;   // min. RMSD for analyzing conformation change
#define RMSD_THR_DEF 0.1  // If confchange projections smaller, discard
#define SEQID_THR_DEF 50  // If Seq.Id<THR, align structures with Mammoth
int NMUT=-1; /* Mutations between the two proteins required for analysis.
	       NMUT=-1: No requirement. NMUT=0: Sequences must be identical.
	       NMUT=1: Exactly one mutation */

// Dynamical couplings
int PRINT_DEF_COUPLING=0;  // Print deformation coupling?
int PRINT_DIR_COUPLING=0;  // Print directionality coupling?
int PRINT_COV_COUPLING=0;  // Print covariance coupling?
int PRINT_COORD_COUPLING=0; // Print coordination coupling?
int PRINT_SIGMA_DIJ=0;  // Print variance of DIJ distanc
int PRINT_CMAT=0;       // Print contact matrix
int STRAIN=0; // Compute strain profile, similar to PNAS 106:14253 2009 ?
int ALL_PAIRS=0; // Print couplings for all pairs?
float SIGMA=1.0; // Print only couplings > SIGMA*std.dev.
char PROF_TYPE='A';
char SITES[100]="";

// Simulation of conformation changes
#define AMPLITUDE_DEF    16.0 // Max. amplitude for normal modes deformations
#define E_THR_DEF        20.0 // Threshold for stopping motion
#define E_THR1_DEF       1.0  // Threshold for deciding privileged direction
#define D_REP_DEF        2.5  // Threshold for repulsions
#define MAX_ANGLE_DEF    0.4  // Max. angle for torsional deformations, radiants

#ifndef __USE_GNU   // this is to use the get_current_dir_name
#define __USE_GNU
#endif

#include "coord.h"
#include "tnm.h"
#include "nma_para.h"
#include "nma.h"

#include "read.h"
#include "dof_tnm.h"
#include "kinetic_tnm.h"
#include "interactions_tnm.h"
#include "screened_interactions.h"
#include "vector.h"
#include "buildup.h"
#include "allocate.h"
#include "McLachlan.h"
#include "align_tnm.h"
#include "output_tnm.h"
#include "contacts.h"
#include "energy_BKV.h"
#include "force2confchange.h"
#include "simulation.h"
#include "allostery.h"
#include "mutation.h"
#include "diagonalize.h"
#include "Fit_B.h"

// #include "rmsd.h"
// #include "rotation.h"

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>


/*********************************************************************/
/**********************  Memory handling  ****************************/
void Allocate_memory(struct Normal_Mode *NM,
		     struct Jacobian *J,
		     float ***Hessian,
		     int N_axes, int N_ref, int N_cart,
		     int N_modes, int N_res);
void Clean_memory(struct Normal_Mode NM,
		  struct Jacobian J,
		  float **Hessian,
		  int N_axes, int N_ref,
		  int N_cart, int N_modes,
		  int ANM);

/***************************  Printing  *********************************/

void Print_summary(double *Mean_Cart_coll,
		   char *name_out, char *name1, char *parameters, int Nchain,
		   struct Normal_Mode NM,
		   float r_B, float RMSD_crys, float RMSD_NM,
		   float kappa, float *f_dof,
		   struct axe *axes, int N_axes, int N_main,
		   int Nskip, int N_atoms, int N_res, int N_diso, int N_int,
		   int N_inter, float Cont_overlap, float Tors_fluct);

/*****************************  Input  *********************************/
int getArgs(int argc, char **argv,
	    char *file_pdb1, char *chain1,
            char *file_pdb2, char *chain2,
	    int *ANM, char *REF,
	    int *SIDECHAINS, int *OMEGA, int *PSI,
	    float *K_OMEGA, float *K_PSI,
	    float *K_PHI, float *K_CHI,
	    float *K_BA, float *K_BL,
	    float *E_MIN, float *COLL_THR,
	    int *MIN_INT, char *INT_TYPE, float *thr,
	    int *S_TYPE, float *S_THR,
	    int *ONEINT, int *N_RESRES,
	    int *N_MODE, char *outdir,
	    int *PRINT_CONFCHANGE, int *PRINT_FORCE,
	    int *PRINT_PDB, int *PRINT_MODE_SUMM,
	    char **FILE_FORCE, int *ALLOSTERY,
	    float *KAPPA, int *FIT_B,
	    float *RMSD_MIN, int *NMUT,
	    struct Para_simul *Para_simul,
	    struct Para_confchange *Para_confchange,
	    float *SEQID_THR,
	    char *parameters,
	    int *PRINT_COV_COUPLING,
	    int *PRINT_DEF_COUPLING,
	    int *PRINT_DIR_COUPLING,
	    int *PRINT_COORD_COUPLING,
	    int *PRINT_SIGMA_DIJ,
	    char *PROF_TYPE,
	    int *ALL_PAIRS, float *SIGMA,
	    int *STRAIN, char *SITES,
	    int *PRINT_CMAT, int *FORCE_STAB);

int Read_para(char *filename,
	      char *file_pdb1, char *chain1,
	      char *file_pdb2, char *chain2,
	      int *ANM, char *REF,
	      int *SIDECHAINS, int *OMEGA, int *PSI,
	      float *K_OMEGA, float *K_PSI,
	      float *K_PHI, float *K_CHI,
	      float *K_BA, float *K_BL,
	      float *E_MIN, float *COLL_THR, int *MIN_INT,
	      char *INT_TYPE, float *thr,
	      int *S_TYPE, float *S_THR,
	      int *ONEINT, int *N_RESRES,
	      int *N_MODE, char *outdir,
	      int *PRINT_CONFCHANGE, int *PRINT_FORCE,
	      int *PRINT_PDB, int *PRINT_MODE_SUMM,
	      char **FILE_FORCE, int *ALLOSTERY,
	      float *KAPPA, int *FIT_B,
	      float *RMSD_MIN, int *NMUT,
	      struct Para_simul *Para_simul,
	      struct Para_confchange *Para_confchange,
	      float *SEQID_THR,
	      int *PRINT_COV_COUPLING,
	      int *PRINT_DEF_COUPLING,
	      int *PRINT_DIR_COUPLING,
	      int *PRINT_COORD_COUPLING,
	      int *PRINT_SIGMA_DIJ,
	      char *PROF_TYPE,
	      int *ALL_PAIRS, float *SIGMA,
	      int *STRAIN, char *SITES,
	      int *PRINT_CMAT, int *FORCE_STAB);
void help (void);

/******************************* Computations ****************************/
int Torsional_Hessian(float **Hessian, int N_modes,
		      struct axe *axe,
		      float K_OMEGA, float K_PSI, float K_PHI, float K_CHI,
		      float K_BA, float K_BL);
int Relevant_modes(float *omega2, int *select, int N, float N_atoms);

extern void Binding_site_dynamics(struct Normal_Mode NM, struct Reference Ref,
				  struct residue *seq, atom *atoms,
				  char *nameout1,
				  char *pdb, char *chain, int Nchain,
				  int Nres, char *SITES);
extern void Center_atoms(atom *atoms, int N_atoms, struct Reference Ref);
extern void Reorient_axes(atom *atoms, int N_atoms, struct Reference Ref);
extern int Periodic_angles(float *dphi, struct axe *axe, int n);

/****************************** Main code  ********************************/

int main(int argc , char *argv[]){

  /****************************  Variables  *******************************/
  // Degrees of freedom
  int PSI=1;        // Use psi angle or freeze it?
  int SIDECHAINS=0; // Use side chains as degrees of freedom?
  int OMEGA=0;      // Use also omega as degree of freedom?
                    // 0=No 1=Yes -1=Yes if Domega>D_omega_thr
  D_omega_thr=90;
  int MIN_INT_MAIN=1; // Minimum number of interactions per degree of freedom
  int MIN_INT_SIDE=1; // Minimum number of interactions per degree of freedom

  // Control
  int ANM=0;
  char INT_TYPE[40];
  //char REF[20]; // In interactions_tnm.h
  int N_MODE_PRINT=0;
  int ALLOSTERY=0;

  
  //float S_THR=0.20;
  //int S_TYPE=0; // type of shadow interaction

  // Struct 1
  int ANISOU1=0;
  int nres1=0, nmr1=0, natoms1=0;
  atom *atoms1=NULL;
  char  file_pdb1[150], chain1[CHMAX], pdbid1[100], nameprot1[100];

  // Mutation
  int FORCE_STAB=1;   // Predict mutation based on stability (1) or size (0)

  struct residue *seq1;
  float *coord_1=NULL;
  struct axe *axe1=NULL;
  int naxe1=0;  // total number of degrees of freedom
  int nmain=0;  // main axes degrees of freedom
  int N_diso1=0;// Number of disordered axis for protein 1
  int nskip=0;  // skipped main chains

  int n_lig1=0, na_lig1=0;
  struct residue *ligres1=NULL;
  atom *ligatom1=NULL;

  // Chains
  int Nchain1=0, Nchain;
  struct chain *chains1=NULL;

  // Struct 2
  int nres2=0, natoms2=0, Nchain2=0;
  int ANISOU2=0, nmr2=0;
  int N_diso2=0; // Number of disordered axis for protein 2
  atom *atoms2=NULL;
  char  file_pdb2[150], chain2[CHMAX], pdbid2[100], nameprot2[100];
  struct residue *seq2;
  float *coord_2=NULL;
  struct chain *chains2=NULL;
  int n_lig2=0, na_lig2=0;
  struct residue *ligres2=NULL;
  atom *ligatom2=NULL;

  // Comparison
  int CONF_CHANGE=0;
  int last_ali_res;
  struct Ali_score ali;
  double rmsd=0.0;
  struct Para_confchange Para_confchange;
  float SEQID_THR=50;

  // Input force
  char *FILE_FORCE=NULL;

  // Simulation
  struct Para_simul Para_simul;

  /* Global (nma_para.h):
     int ALL_AXES;
     float EXP_HESSIAN;
     int PRINT_LAMBDA;
     int PRINT_AXES;
   */

  // GO Model
  float **Hessian=NULL;
  int N_int=0;
  float Cont_overlap=-1;

  // Reference
  struct Reference Ref_kin, Ref1, Ref2;

  // Kinematics
  struct Jacobian J;

  // Normal modes
  struct Normal_Mode NM;

  // Dummies
  // int i,j,k,l,jj, ia, ib, na, nc, a;
  int i,ia,k;

  // time
  double nbtops = CLOCKS_PER_SEC, t0=clock();

  // File names
  #define NCH 150
  char outdir[NCH]="", nameout1[NCH]="", summary1[NCH]=""; //directory[150],
  char fullmodel[NCH]="", MODEL[80]="";
  char name2[NCH]="", nameout2[NCH]="", summary2[NCH]="";
  char parameters[1000]="";

  /*****************************  INPUT  **********************************/
  int PRINT_CONFCHANGE=0;
  int PRINT_FORCE=PRINT_FORCE_DEF;
  int PRINT_PDB= PRINT_PDB_DEF;
  int PRINT_MODE_SUMM=PRINT_MODE_SUMM_DEF;

  outdir[0]='\0';
  ALL_AXES=1;
  KINETIC=1;
  E_MIN=E_MIN_DEF;
  ONEINT=1;
  N_RESRES=1;
  HYD=0; HYD_REF=0; // Read hydrogen atoms or not?
  getArgs(argc,argv,file_pdb1,chain1,file_pdb2, chain2,
	  &ANM, REF, &SIDECHAINS, &OMEGA, &PSI,
	  &K_OMEGA, &K_PSI, &K_PHI, &K_CHI, &K_BA, &K_BL,
	  &E_MIN, &COLL_THR, &MIN_INT_SIDE, INT_TYPE, &C_THR, &S_TYPE,
	  &S_THR, &ONEINT, &N_RESRES, &N_MODE_PRINT, outdir,
	  &PRINT_CONFCHANGE, &PRINT_FORCE, &PRINT_PDB, &PRINT_MODE_SUMM,
	  &FILE_FORCE, &ALLOSTERY, &KAPPA, &FIT_B, &RMSD_MIN, &NMUT,
	  &Para_simul, &Para_confchange, &SEQID_THR, parameters,
	  &PRINT_COV_COUPLING, &PRINT_DEF_COUPLING,
	  &PRINT_DIR_COUPLING, &PRINT_COORD_COUPLING,
	  &PRINT_SIGMA_DIJ, &PROF_TYPE, &ALL_PAIRS, &SIGMA, &STRAIN, SITES,
	  &PRINT_CMAT, &FORCE_STAB);
  MIN_INT_MAIN=MIN_INT_SIDE;
  Econt=Allocate_mat2_f(20, 20);
  for(i=0; i<20; i++)for(k=0; k<20; k++)Econt[i][k]=E_BKV[i][k];
  AA_code=AA_BKV;

  // Control parameters
  if(HNM){
    strcpy(MODEL, "HNM");
    strcpy(REF, "CA");
    strcpy(INT_TYPE, "CA");
    printf("WARNING, Hinsen ANM (HNM) chosen, ");
    printf("setting interaction types and ref. atoms to CA\n");
    ANM=1;
  }
  if(ANM){
    char REFT[4]="CA";
    strcpy(MODEL, "ANM");
    if((strncmp(INT_TYPE, "MIN", 3)==0)||
       (strncmp(INT_TYPE, "ALL", 3)==0)){
      strcpy(INT_TYPE, "SCA");
      printf("WARNING, all atoms contacts but interacting atoms set to CA.");
    }else if((strncmp(INT_TYPE, "CB", 2)==0)||
	     (strncmp(INT_TYPE, "SCB", 3)==0)){
      strcpy(REFT, "CB");
    }else if(strncmp(INT_TYPE, "CA", 2)!=0){
      printf("WARNING, interaction type %s not allowed with ANM\n", INT_TYPE);
      strcpy(INT_TYPE, "CA");
    }
    if(strcmp(REF, REFT)!=0){
      printf("WARNING, %s not allowed reference atoms with ANM.", REF);
      printf("Reference atoms set to %s\n", REFT);
      strcpy(REF, REFT);
    }
    printf("ANM (Cartesian d.o.f.) ");
    //E_MIN*=10;
  }else{
    // TNM
    strcpy(MODEL, "TNM");
    if(REF[0]=='\0')strcpy(REF, REF_DEF);
    char REFT[4]; strcpy(REFT, REF);
    if((strncmp(INT_TYPE, "CA", 2)==0)||
       (strncmp(INT_TYPE, "SCA", 3)==0)){
	strcpy(REFT, "CA");
    }else if((strncmp(INT_TYPE, "CB", 2)==0)||
	     (strncmp(INT_TYPE, "SCB", 3)==0)){
	strcpy(REFT, "CB");
    }else if(strncmp(INT_TYPE, "HYD", 3)==0){
      HYD=1; HYD_REF=0;
    }
    if((strcmp(REF,REFT)!=0)&&(strcmp(REF,"ALL")!=0)&&(strcmp(REF,"EB")!=0)){
      printf("WARNING, %s not allowed reference atoms with %s contacts",
	     REF, INT_TYPE);
      printf(" Setting reference atoms to %s\n", REFT);
      strcpy(REF, REFT);
    }
  }
  printf("Reference atoms: %s Contact type: %s\n", REF, INT_TYPE);
  NM.ANM=ANM;

  /********************  Protein structure 1  ***********************/
  /* Read protein structure 1*/
  Read_PDB(&nres1, &seq1, &n_lig1, &ligres1, chain1, &ANISOU1, &nmr1,
	   &natoms1, &atoms1, &na_lig1, &ligatom1, &chains1, &Nchain1,
	   pdbid1, file_pdb1);
  Nchain=Nchain1;
  //N_TNM=naxe1;

  /*******************  Protein structure 2, if any  ********************/
  /* Read protein structure 2 */
  int Nmut=0, *Posmut=NULL; char *AAmut=NULL;
  if(file_pdb2[0]!='\0'){
    Read_PDB(&nres2, &seq2, &n_lig2, &ligres2, chain2, &ANISOU2,
	     &nmr2, &natoms2, &atoms2, &na_lig2, &ligatom2,
	     &chains2, &Nchain2, pdbid2, file_pdb2);
    if(nres2<=0){
      printf("WARNING, no residues found in file %s\n", file_pdb2);
      printf("Performing single structure computation\n"); goto end_ali;
    }
    CONF_CHANGE=1;
    MIN_ALI_LEN=MIN_ALI_LEN_DEF;
    Posmut=malloc(nres2*sizeof(int));
    AAmut=malloc(nres2*sizeof(char));
    Align_chains(&Nmut, Posmut, AAmut, &ali, &last_ali_res,
		 &Nchain, SEQID_THR,
		 chains1, Nchain1, seq1, pdbid1,
		 chains2, Nchain2, seq2, pdbid2);
    if((NMUT>=0)&&(Nmut!=NMUT)){
      printf("WARNING, %d mutations found, %d expected. ", Nmut, NMUT);
      printf("Setting the parameter NMUT to -1\n");
      NMUT=-1;
    }
    int N_ali_atom=0;
    for(i=0; i<Nchain1; i++){
      struct chain *ch1= chains1+i, *ch2= chains2+ch1->match;
      if(i<Nchain){
	int num=Align_atoms(atoms1, atoms2, ch1, ch2);
	N_ali_atom+=num;
      }else{
	for(int j=ch1->ini_atom; j<(ch1->ini_atom+ch1->natoms); j++){
	  atoms1[j].ali=-1;
	}
      }
    }
    printf("%d aligned atoms out of %d and %d in %d chains\n",
	   N_ali_atom, natoms1, natoms2, Nchain);

    // Eliminate not aligned atoms before setting bonds and reference atoms
    // Also maintain not aligned atoms that belong to aligned residues
    if(SWITCH_BONDS){
      Purge_not_aligned(chains1, atoms1, &natoms1,
			chains2, atoms2, &natoms2);
      printf("Prot 1: %d Prot 2: %d\n", natoms1, natoms2);
      // From this point on, atoms1[i].ali=i
    }
  }
 end_ali:
  if(CONF_CHANGE==0){
    last_ali_res=nres1;
    for(i=0; i<natoms1; i++)atoms1[i].ali=i;
  }

  /*************  Reference atoms for kinetic energy  ***********************/
  int N_ref=Set_reference(&Ref_kin, 0, REF, atoms1, 0, natoms1);
  int N_cart=3*N_ref;
  // Check that reference atoms exist
  if((natoms1==0)||(N_ref==0)){
    printf("ERROR, no atoms found in file %s", file_pdb1);
    printf(" natoms= %d N_ref= %d\n", natoms1, N_ref);
    exit(8);
  }

  /*******************************************************************/
  // Change the coordinate system
  // Put center of mass at the origin
  Center_atoms(atoms1, natoms1, Ref_kin);
  // Reorient the Cartesian axes along the principal axes
  Reorient_axes(atoms1, natoms1, Ref_kin);

  /********** If(CONFCHANGE), exit if RMSD is too small   ************/

  if(CONF_CHANGE){
    //if((strcmp(REF,"ALL")==0)&&(SIDECHAINS==0)){
    if(0){
      strcpy(REF_CC, "EB");
      Set_reference(&Ref1, 0, REF_CC, atoms1, 0, natoms1);
    }else{
      strcpy(REF_CC, REF); Ref1=Ref_kin;
    }

    // Write coordinates of reference atoms into arrays
    coord_1=malloc(Ref1.N_cart*sizeof(float));
    Write_ref_coord_atom(coord_1, Ref1.N_ref, atoms1, Ref1.atom_num);

    Ref2.atom_num=malloc(natoms2*sizeof(int));
    for(i=0; i<Ref1.N_ref; i++){
      Ref2.atom_num[i]=atoms1[Ref1.atom_num[i]].ali;
      if(Ref2.atom_num[i]<0){
	printf("ERROR, wrong reference atom %d i=%d i1=%d\n",
	       Ref2.atom_num[i], i, Ref1.atom_num[i]); exit(8);
      }
    }
    coord_2=malloc(Ref1.N_cart*sizeof(float));
    Write_ref_coord_atom(coord_2, Ref1.N_ref, atoms2, Ref2.atom_num);
    rmsd=rmsd_mclachlan_f(coord_1, coord_2, Ref1.mass_atom, Ref1.N_ref);
    if((rmsd < RMSD_MIN)||(rmsd > RMSD_MAX)){
      printf("Exiting TNM: RMSD(%s,%s)=%.2f, allowed: %.2f-%.2f\n",
	     pdbid1, pdbid2, rmsd, RMSD_MIN, RMSD_MAX); exit(8);
    }
    printf("Conformation change, RMSD= %.2f\n", rmsd);
  }

  /************************  Output files ***************************/
  sprintf(nameprot1, "%s", pdbid1);
  for(i=0; i<Nchain; i++){
    if((chains1[i].label!=' ')&&(chains1[i].label!='\0'))
      sprintf(nameprot1, "%s%c", nameprot1, chains1[i].label);
  }
  if(strncmp(INT_TYPE, "SCR", 3)==0){
    if(ONEINT==0){
      sprintf(fullmodel, "%s_d%.2f_t%.1f", INT_TYPE, S_THR, C_THR);
    }else{
      sprintf(fullmodel, "%s_MIN_d%.2f_t%.1f", INT_TYPE, S_THR, C_THR);
    }
  }else if(strncmp(INT_TYPE, "SHA", 3)==0){
    if(ONEINT==0){
      sprintf(fullmodel, "%s_%d_d%.2f_t%.1f", INT_TYPE, S_TYPE, S_THR, C_THR);
    }else{
      sprintf(fullmodel, "%s_MIN_%d_d%.2f_t%.1f",
	      INT_TYPE, S_TYPE, S_THR, C_THR);
    }
  }else if((strncmp(INT_TYPE, "MIN", 3)==0)&&(N_RESRES>1)){
    sprintf(fullmodel, "%s%.1f_M%d", INT_TYPE, C_THR, N_RESRES);
  }else{
    sprintf(fullmodel, "%s%.1f", INT_TYPE, C_THR);
  }
  sprintf(fullmodel, "%s_%s_%s", fullmodel, MODEL, REF);
  if(SIDECHAINS)sprintf(fullmodel, "%s_SCHAIN", fullmodel);
  if(OMEGA>0){
    sprintf(fullmodel, "%s_OMEGA", fullmodel);
  }else if(OMEGA<0){
    sprintf(fullmodel, "%s_CISTRANS", fullmodel);
  }
  if(PSI==0)sprintf(fullmodel, "%s_NOPSI", fullmodel);
  sprintf(nameout1,  "%s_%s", nameprot1, fullmodel);
  sprintf(summary1, "Summary_%s.dat", nameout1);   
  if(Check_make_dir(outdir)){
    sprintf(summary1, "%s/%s", outdir, summary1);
    sprintf(nameout1,  "%s/%s", outdir, nameout1);
  }
  if(CONF_CHANGE){
    sprintf(nameprot2, "%s", pdbid2);
    for(i=0; i<Nchain; i++){
      if((chains2[i].label!=' ')&&(chains2[i].label!='\0'))
	sprintf(nameprot2, "%s%c", nameprot2, chains2[i].label);
    }
    sprintf(name2, "%s-%s", nameprot1, nameprot2);
    sprintf(nameout2, "%s-%s_%s", nameprot1, nameprot2, fullmodel);
    sprintf(summary2, "Summary_%s.dat", nameout2);
    if(Check_make_dir(outdir)){
      sprintf(summary2, "%s/%s", outdir, summary2);
      sprintf(nameout2, "%s/%s", outdir, nameout2);
    }
  }

  /*******************************************************************
                          ENM Computations
  ********************************************************************/
  //Scale_interactions(INT_TYPE, atoms1, natoms1, nres1);

  // Consider covalent contacts in ANM but not in TNM
  NOCOV=1; if(ANM)NOCOV=0;

  /*************************  Interactions  *************************/
  struct interaction *Int_list; 
  Compute_interactions(&N_int, &Int_list, INT_TYPE, atoms1, natoms1, nres1);
  if(PRINT_CMAT){
    Print_contact_matrix(Int_list,N_int,atoms1,seq1,fullmodel,nameprot1);
  }
  printf("%d interactions %d ref.atoms\n", N_int, N_ref);
  int N_inter=0;  // Count interchain interactions
  if(Nchain > 1){
    for(k=0; k<N_int; k++){
      if(atoms1[Int_list[k].i1].chain!=atoms1[Int_list[k].i2].chain)
	N_inter++;
    }
    printf("%d Interchain contacts\n", N_inter);
  }

  if((strncmp(INT_TYPE, "SCR", 3)==0)||(strncmp(INT_TYPE, "SHA", 3)==0)){ 
      // Screened interactions
    int alignres[nres1], N_int3;
    for(i=0; i<nres1; i++)alignres[i]=i;
    struct interaction *Int_list3;
    Compute_interactions(&N_int3, &Int_list3, "MIN", atoms1, natoms1, nres1);
    Cont_overlap=Contact_overlap(Int_list3,N_int3,Int_list,N_int,alignres);
    printf("MIN: %d interactions q=%.3f (%s-MIN)\n",
	   N_int3, Cont_overlap, INT_TYPE);
    free(Int_list3);
  }
  printf("Contact matrix computation.Time= %.2lf sec.\n",(clock()-t0)/nbtops);
  t0=clock();

  /***********************  Degrees of freedom ************************/
  // bonds are made only for atoms with ali=1!
  struct bond *bonds=Set_bonds_topology(natoms1, atoms1, seq1);
  // Test bonds
  int naxe=3*nres1;
  Test_buildup(bonds, atoms1, natoms1, naxe);
  if((CONF_CHANGE)&&((SWITCH_BONDS)||(OMEGA<0))){
    // Internal degrees of freedom are analyzed here.
    // bond->d_phi is computed here
    Switch_bonds(bonds, naxe, name2,
		 atoms1, natoms1, seq1, Ref1,
		 atoms2, natoms2, seq2, Ref2);
  }
  axe1=Set_DegofFreed(&naxe1, &nmain, &nskip, &N_diso1, bonds,
		      atoms1, natoms1, Ref_kin.atom_num, N_ref,
		      seq1, last_ali_res, chains1, Nchain,
		      Int_list, N_int, MIN_INT_MAIN, MIN_INT_SIDE,
		      OMEGA, SIDECHAINS, PSI);
  printf("Number of degrees of freedom: %d\n", naxe1);
  if(naxe1!=nmain)printf("Side chains dof: %d\n", naxe1-nmain);

  // Standardize bond lengths and bond angles
  int STANDARDIZE=0;
  if(STANDARDIZE){
    Standardize_bonds(bonds, atoms1, natoms1, nameprot1,
		      axe1, naxe1, seq1, nres1, chains1,
		      Nchain, 0.1, Para_simul);
  }

  /************************ Prepare memory ***************************/
  int N_modes;
  if(ANM){N_modes=N_cart;}else{N_modes=naxe1;}
  Allocate_memory(&NM, &J, &Hessian, naxe1, N_ref, N_cart, N_modes, nres1);
  printf("Memory allocated\n");

  /********* Eckart conditions, Jacobian, Kinetic energy  ************/
  J.N_kin=
    Compute_kinetic(&J, axe1, naxe1, atoms1, natoms1, Ref_kin);
  if((ANM==0)&&(KINETIC)){N_modes=J.N_kin; NM.N=N_modes;}
  printf("Kinetic energy computation. Time= %.2lf sec.\n",(clock()-t0)/nbtops);
  t0=clock();

  /************************** Debugging *****************************/
  if(DEBUG){
    for(i=0; i<Nchain; i++){
      struct chain *chp=chains1+i;
      printf("### Chain %c\n", chp->label);
      printf("%3d axes: %d - %d\n", chp->mainaxes,
	     chp->ini_main, chp->ini_main+chp->mainaxes-1);
      printf("%4d atoms: %d - %d\n", chp->natoms,chp->ini_atom,
	     chp->natoms+chp->ini_atom-1);
      printf("%3d residues: %d - %d\n", chp->nres,chp->ini_res,
	     chp->nres+chp->ini_res-1);
    }
  }

  /*************************  Normal modes TNM *************************/
  if(ANM==0){ // TNM
    printf("Torsional network model\n");
    if(KINETIC==0)printf("WARNING, kinetic energy not considered\n\n");
    Compute_Hessian_TNM(Hessian, J.T_sqrt, J.T_sqrt_inv, Int_list, N_int,
			atoms1, natoms1, axe1, nmain, naxe1, N_modes,
			chains1, Nchain, KINETIC,
			K_OMEGA, K_PSI, K_PHI, K_CHI, K_BA, K_BL);

    printf("Hessian computation. Time= %.2lf sec.\n",(clock()-t0)/nbtops);
    t0=clock();

    f_Diagonalize(N_modes, Hessian, NM.omega2, NM.MW_Tors, -1);
    printf("Hessian diagonalization. Time= %.2lf sec.\n", (clock()-t0)/nbtops);
    t0=clock();

    // Allocate only relevant modes
    //NM.N_relevant=Relevant_modes(NM.omega2, NM.select, NM.N, NM.N_cart/40);
    NM.N_relevant=NM.N;
    NM.Cart=Allocate_mat2_f(NM.N_relevant, NM.N_cart);
    for(ia=0; ia<NM.N_relevant; ia++){
      Transform_tors_modes(NM.Tors[ia], NM.MW_Tors[ia],
			   J.T_sqrt_tr, J.T_sqrt_inv_tr,
			   N_modes, naxe1);
      Convert_torsion2cart(NM.Cart[ia], atoms1, NM.Tors[ia],
			   axe1, naxe1, Ref_kin, ia);
    }

  /*************************  Normal modes ANM *************************/
  }else{ // ANM
    if(HNM){printf("Hinsen network model");}
    else{printf("Anisotropic network model\n");}

    Compute_Hessian_ANM(Hessian, N_ref, Ref_kin.atom_num,
			Int_list, N_int, atoms1, natoms1);
    printf("Hessian computation. Time= %.2lf sec.\n",(clock()-t0)/nbtops);

    NM.Cart=Allocate_mat2_f(NM.N_cart, NM.N_cart);
    f_Diagonalize(N_modes, Hessian, NM.omega2, NM.Cart, -1);
    printf("Hessian diagonalization. Time= %.2lf sec.\n", (clock()-t0)/nbtops);
    t0=clock();
    
    //  Convert normal modes
    struct Tors *D_NM=malloc(N_modes*sizeof(struct Tors));
    for(ia=0; ia<NM.N_relevant; ia++){
      //if(ia<10)printf("om2= %.2g\n", NM.omega2[ia]);
      Normalize_vector_weighted(NM.Cart[ia], Ref_kin.mass_coord, N_cart);
      D_NM[ia].Cart=NM.Cart[ia];
      D_NM[ia].Tors=NM.Tors[ia];
      D_NM[ia].MW_Tors=NM.MW_Tors[ia];
      D_NM[ia].coeff=malloc(1*sizeof(float));
      D_NM[ia].N_axes=naxe1;
      D_NM[ia].N_cart=N_cart;
      Convert_cart2torsion(&(D_NM[ia]), Ref_kin, &J);
      NM.Tors_frac[ia]=Tors_fraction(&(D_NM[ia]), Ref_kin.mass_coord);
    }
  }
  printf("Normal mode computation. Time= %.2lf sec.\n",
	 (clock()-t0)/nbtops);
  t0=clock();

  /********************  Collectivity of normal modes *******************/
  // Select modes based on eigenvalues
  int N_dis=0;
  // N_dis=Select_modes(NM.select, NM.omega2, E_MIN, NM.N);
  // Select modes based on collectivity
  Ref_kin.inv_sq_mass=malloc(N_cart*sizeof(float));
  for(i=0; i<N_cart; i++)Ref_kin.inv_sq_mass[i]=1./sqrt(Ref_kin.mass_coord[i]);
  for(ia=0; ia<NM.N_relevant; ia++){

    NM.Max_dev[ia]=Compute_Max_dev(NM.Cart[ia], NM.omega2[ia], N_cart,
				   KAPPA, Ref_kin.inv_sq_mass);
    NM.Tors_coll[ia]=Collectivity_norm2(NM.Tors[ia], naxe1)/naxe1;
    NM.MW_Tors_coll[ia]=Collectivity_norm2(NM.MW_Tors[ia],naxe1)/naxe1;
    NM.Cart_coll[ia]=Collectivity_norm2(NM.Cart[ia], N_cart); //_Renyi
    if((NM.omega2[ia]<=0)||(NM.Cart_coll[ia] < COLL_THR)){
      printf("WARNING, discarding mode %d ", ia);
      printf(" omega^2= %.3g Coll= %.0f RMSD= %.2g\n",
	     NM.omega2[ia], NM.Cart_coll[ia], NM.Max_dev[ia]);
      NM.select[ia]=0; N_dis++;
    }else{
      NM.select[ia]=1;
    }
    NM.Cart_coll[ia]/=N_cart;
  }
  printf("%d relevant modes selected. Time= %.2lf sec.\n",
	 NM.N_relevant-N_dis, (clock()-t0)/nbtops);
  printf("%d discarded modes of low colectivity\n", N_dis);
  t0=clock();

  /************************ Debugging *****************************/
  if(DEBUG &&(ANM==0)){
    int ib;
    float **ev=NM.MW_Tors;
    printf("Scalar product between mass-weighted TNM modes\n");
    for(ia=0; ia<20; ia++){
      for(ib=0; ib<=ia; ib++)
	printf(" %.3f", Scalar_product(ev[ia],ev[ib],naxe1));
      printf("\n");
    }
    printf("Scalar product between mass weighted Cartesian TNM modes\n");
    for(ia=0; ia<20; ia++){
      if(ia>=NM.N_relevant)continue;
      for(ib=0; ib<=ia; ib++){
	float *Ca=NM.Cart[ia], *Cb=NM.Cart[ib]; double q=0;
	for(i=0; i<N_cart; i++)q+=Ca[i]*Cb[i]*Ref_kin.mass_coord[i];
	printf(" %.3f", q);
      }
      printf("\n");
    }
  }

  /************** Fit B factors and rescale frequencies **************/
  double sum_omega_minus2=0; N_dis=0;
  for(i=0; i<N_modes; i++){ //N_modes
    if((NM.select[i]==0)||(NM.omega2[i]<=0)){
      NM.contr2fluct[i]=0; N_dis++;
    }else{
      NM.contr2fluct[i]=1./NM.omega2[i];
      sum_omega_minus2+=NM.contr2fluct[i];
    }
  }
  printf("%d discarded modes for B factors\n", N_dis);
  float slope=0, offset=0, slope_NoRot=0, f_dof[3]; 
  float *B_exp=malloc(N_ref*sizeof(float)), B_TNM[N_ref];
  float Xref[(3*nres1)];
  double pi=3.1415, norm=8.0*pi*pi/3;
  double bsum=0, bsum2=0, mass_sum=0;
  int Na=0, j=0, Bref[nres1];
  char BSEL[4]="CA";
  if(strcmp(REF, "CB")==0)strcpy(BSEL, "CB");
  for(i=0; i<N_ref; i++){
    atom *atm=atoms1+Ref_kin.atom_num[i];
    if((strncmp(atm->name, BSEL, 2)!=0)&&
       ((seq1[atm->res].amm!='G')||(strncmp(atm->name, "CA", 2)!=0)))continue;
    Bref[Na]=Ref_kin.atom_num[i];
    B_TNM[Na]=Compute_correlation(NM.Cart,NM.contr2fluct,NM.N_relevant,i,i);
    B_TNM[Na]*=norm;
    //if(ANM)B_TNM[Na]/=Ref_kin.mass_atom[i];
    B_exp[Na]=atm->B_factor; // /norm
    for(k=0; k<3; k++){Xref[j]=atm->r[k]; j++;}
    bsum+=B_exp[Na]; bsum2+=B_exp[Na]*B_exp[Na];
    mass_sum+=Ref_kin.mass_atom[i];
    Na++;
  }
  bsum/=Na; bsum2=(bsum2/Na-bsum*bsum);
  float RMSD_crys=0, RMSD_NM=0, r_B=0, bsmall=0.01;
  float *B_pred_all=malloc(nres1*sizeof(float));
  char ridge='M'; float kappa=KAPPA;
  int outlier[Na]; for(i=0; i<Na; i++)outlier[i]=0;
  if((FIT_B)&&(bsum > bsmall)&&(bsum2>bsmall)){
    float r;
    slope=Bfactors_fit(&r_B, outlier, f_dof, B_pred_all, B_exp, B_TNM,
		       Xref, Na, nameout1, ridge);
    kappa=norm/slope;
    printf("force const=%.4g\n", kappa);
    //r=Fit_no_outliers(outlier, B_TNM, B_exp, Na, &slope_NoRot, &offset);
    r=Corr_coeff(B_TNM, B_exp, Na, &slope_NoRot, &offset);
    printf("r(B_pred,B_exp)= %.3f offset= %.3f force const=%.4g",
	   r, offset/norm, norm/slope_NoRot);
    printf(" (2 var fit)\n");
    RMSD_crys=sqrt(Na*bsum/(norm*mass_sum));
  }
  if((bsum < bsmall)||(bsum2<bsmall)||(r_B<R_MIN)||(slope<SLOPE_MIN)){
    printf("WARNING, no Bfact or r_B= %.2f or Bfact slope= %.2g too small",
	   r_B, slope);
    printf(" Using force constant= %.2g\n", KAPPA);
    FIT_B=0; kappa=KAPPA;
  }
  if(FIT_B==0){
    kappa=KAPPA;
    printf("Setting force constant to %.3g\n", KAPPA);
    slope=1./KAPPA; r_B=0;
    free(B_exp); B_exp=NULL;
    free(B_pred_all); B_pred_all=NULL;
  }else{
    printf("Force constant fitted to B factors\n");
  }
  //  Print B factors
  RMSD_NM=sqrt(sum_omega_minus2*slope/mass_sum);
  for(i=0; i<Na; i++)B_TNM[i]*=slope;
  Print_cart_fluct0(B_TNM, B_pred_all, B_exp, Na, atoms1, Bref,
		    seq1, nameout1, "Bfact", r_B, slope, f_dof, ridge);
  printf("RMSD of fluctuation (exp)= %.3f sum(1/omega^2)/Mass= %.3f\n",
	 RMSD_crys, RMSD_NM);
  printf("slope= %.3f sum_omega_minus2=%.2f\n", slope, sum_omega_minus2);
  sum_omega_minus2/=slope;
  for(i=0; i<N_modes; i++){
    NM.omega2[i]/=slope;
    NM.omega[i]=sqrt(NM.omega2[i]);
    NM.contr2fluct[i]/=sum_omega_minus2;
  }
  if(B_exp)free(B_exp); if(B_pred_all)free(B_pred_all);

  /*if(ANISOU){
    int n_aniso=0, *weight=malloc(N_ref*sizeof(int));
    float dot_aniso=0, ov_aniso=0, delta_aniso=2.;
    float **aniso_exp=malloc(N_ref*sizeof(float **));
    float **aniso_pred=malloc(N_ref*sizeof(float **));
    Compute_anisou(aniso_pred, N_modes, N_ref, eigen_B, Cart_mode);
    n_aniso=Compare_anisou(aniso_pred, aniso_exp, nca, model, inter,
    file_aniso, prot_name, N, weight,
    &dot_aniso, &ov_aniso, &delta_aniso);
    fprintf(file_sum, " %3d %.3f %6.3f %.4f",
    n_aniso, ov_aniso, dot_aniso, delta_aniso);
    }*/
  printf("Fitting B factors. Time= %.2lf sec.\n", (clock()-t0)/nbtops);
  t0=clock();

 /*********************  RMSF of torsion angles ********************/
  NM.tors_fluct=malloc(NM.N_axes*sizeof(float));
  NM.cart_fluct=malloc(N_cart*sizeof(float));
  Predict_fluctuations(&NM);
  double Tors_fluct=0;
  for(i=0; i<NM.N_axes; i++){float x=NM.tors_fluct[i]; Tors_fluct+=x*x;}
  Tors_fluct=sqrt(Tors_fluct/NM.N_axes);
  Print_tors_fluct2(NM, axe1, naxe1, seq1, nameout1);
  int outlier_tors[naxe1];
  Tors_outliers(outlier_tors, naxe1, outlier, Na, axe1, chains1, Nchain);

  /************************ Print_summary *****************************/

  char *summary, *nameprot;
  if(CONF_CHANGE){
    summary=summary2; nameprot=name2;
  }else{
    summary=summary1; nameprot=nameprot1;
  }

  // Single protein properties
  // Mean_Cart_coll and Coll_thr_cc are computed here
  Print_summary(&Mean_Cart_coll, summary, nameprot, parameters, Nchain, NM,
		r_B, RMSD_crys, RMSD_NM, kappa, f_dof, 
		axe1, naxe1, nmain, nskip, natoms1, nres1, N_diso1,
		N_int, N_inter, Cont_overlap, Tors_fluct);
  if((PRINT_MODE_SUMM)&&(CONF_CHANGE==0)){
    Print_mode_summary(nameout1, "Modes", NM, sqrt(mass_sum));
  }
  
  /*********************  Conformation change  **********************/
  if(CONF_CHANGE){
    struct Jacobian *J_CC=NULL; int Change_J=0;
    if(strncmp(REF_CC, REF, 3)==0){
      J_CC=&J;
    }else{
      Change_J=1; J_CC=malloc(1*sizeof(struct Jacobian));
      Allocate_Jacobian(J_CC, naxe1, Ref1.N_cart);
      int first_kin[naxe1], last_kin[naxe1];
      Change_kin(first_kin, last_kin, axe1, naxe1, natoms1, Ref1);
      J_CC->N_kin=Compute_kinetic(J_CC, axe1, naxe1, atoms1, natoms1,Ref1);
      Change_kin_back(axe1, naxe1, first_kin, last_kin);
    }
    struct Tors Diff;
    Allocate_tors(&Diff, naxe1, Ref1.N_cart, N_modes);

    // Difference of torsion angles
    float *diff_phi=NULL;
    if(SWITCH_BONDS){
      struct bond *bonds2=Set_bonds_topology(natoms2, atoms2, seq2);
      Set_bonds_measure(bonds, natoms1, atoms1);
      Set_bonds_measure(bonds2,natoms2, atoms2);
      // IMPORTANT: Not aligned atoms have been previously eliminated
      // diff_phi=Compute_diff_phi(bonds, natoms1, bonds2, naxe1, 1);
      diff_phi=malloc(naxe1*sizeof(float));
      Change_internal(diff_phi, naxe1, bonds, bonds2, natoms1, 0, 0);
      /*float phi1[naxe1];
      Internal_coordinates(phi1, naxe1, bonds, natoms1);
      Internal_coordinates(diff_phi, naxe1, bonds2, natoms2);
      for(i=0; i<naxe1; i++)diff_phi[i]-=phi1[i];*/
      Periodic_angles(diff_phi, axe1, naxe1);
      free(bonds2);
    }

    // Iterative procedure
    float *greedy_phi=NULL;
    if(PRINT_CONFCHANGE && (ANM==0)){
      printf("Interpolating torsional conformation change\n");
      greedy_phi=
	Torsional_confchange("greedy", 0.1, atoms1, natoms1, nameout2,
			     axe1, naxe1, seq1, nres1, chains1, Nchain,
			     atoms2, natoms2, bonds, Para_simul);
      /* 
      //Check
      float coord_all[3*natoms1], coord_new[3*N_ref];
      Set_bonds_measure(bonds, natoms1, atoms1);
      Build_up(bonds, natoms1, greedy_phi, naxe1);
      Put_coord(coord_all, bonds, natoms1);
      Write_ref_coord(coord_new, N_ref, coord_all, Ref1.atom_num);
      float RMSD=rmsd_mclachlan_f(coord_2, coord_new, Ref1.mass_atom, N_ref);
      printf("Repeat RMSD= %.2f\n\n", RMSD);
      exit(8);*/

      printf("\nMaking conformation change. Time= %.2lf sec.\n",
	     (clock()-t0)/nbtops); t0=clock();
    }

    char namepdb[400]; sprintf(namepdb, "%s_%s", name2, REF);
    if(OMEGA>0){
      sprintf(namepdb, "%s_OMEGA", namepdb);
    }else if(OMEGA<0){
      sprintf(namepdb, "%s_CISTRANS", namepdb);
    }
    if(PSI==0)sprintf(namepdb, "%s_NOPSI", namepdb);
    rmsd=Examine_confchange(&Diff, bonds, axe1, summary2, nameprot2, namepdb,
			    atoms1, coord_1, seq1, nres1, N_diso1, natoms1,
			    atoms2, coord_2, seq2, nres2, N_diso2, natoms2,
			    Int_list, N_int, INT_TYPE, s0,
			    N_modes, Ref1, J_CC, NM, 1, ali,
			    Para_confchange, diff_phi, greedy_phi,
			    0, B_TNM, outlier_tors, nameout2); 
    Print_modes_confchange(name2,nameout2,NM,Diff,ANM,sqrt(mass_sum),rmsd);
    printf("Writing %s\n", summary);
    printf("Output conf.change. Time= %.2lf sec.\n\n",
	   (clock()-t0)/nbtops); t0=clock();

    // Analysis of mutation
    /*float mut_phi[naxe1], mut_CC[N_cart];
    if(Mutation(mut_phi, naxe1, mut_CC, // output
		Ref_kin, Nmut, Posmut, AAmut, FORCE_STAB,
		NM, atoms1, natoms1, Int_list, N_int, seq1, B_TNM,
		Diff.Cart, Ref1, Diff.Tors,
		NM.tors_fluct, nameout2))
      {
	Simulate_confchange(30, mut_phi, mut_CC, 1, RMSD_NM, coord_1, coord_2,
			    rmsd, Para_simul, Para_confchange, atoms1, natoms1,
			    axe1, naxe1, bonds, seq1, nres1, N_diso1, NM, *J_CC,
			    Ref1, Int_list, N_int, INT_TYPE, s0, nameout2,
			    Tors_fluct);
	printf("Analysis of mutation. Time= %.2lf sec.\n",
	       (clock()-t0)/nbtops); t0=clock();
	       }*/

    /* Computing and printing force producing confchange
       The force is computed for all atoms of kynetic energy (Ref_kin),
       not only those representative of conformation change (Ref1) */
    struct Tors Force;
    Compute_force(&Force, Diff.coeff, NM);
    float k_Force_cart=Collectivity_norm2(Force.Cart, 3*N_ref);
    FILE *file_out=fopen(summary2, "a");
    fprintf(file_out, "Coll(force_Lambda)     %.0f\n", k_Force_cart);
    fclose(file_out);
    if(PRINT_FORCE){
      float F_module[N_ref];
      int j=0;
      for(i=0; i<N_ref; i++){
	F_module[i]=
	  Force.Cart[j]*Force.Cart[j]+
	  Force.Cart[j+1]*Force.Cart[j+1]+
	  Force.Cart[j+2]*Force.Cart[j+2];
	j+=3;
      }
      char namepdb[200]; sprintf(namepdb, "%s_force.pdb", nameout2);
      Print_cart_fluct(Ref_kin.atom_num, N_ref, F_module, atoms1, seq1,
		       namepdb,"FORCE");
      Print_force_confchange(NM, Diff, atoms1, axe1, naxe1, seq1, nres1,
			     nameout2);
    }
    printf("Computing and printing force. Time= %.2lf sec.\n",
	   (clock()-t0)/nbtops); t0=clock();
    Empty_tors(Force);
    Empty_tors(Diff); // double free, why?
    if(Change_J)Empty_Jacobian(*J_CC);
    if(diff_phi)free(diff_phi);
    if(greedy_phi)free(greedy_phi);
  }
  /************************** End of conformation change **************/

  /********************** Print all modes *****************************/
  int N_print=N_MODE_PRINT;
  if(N_print>NM.N_relevant)N_print=NM.N_relevant;
  if(N_print){
    Print_modes(N_print, nameout1, "Cartmodes", NM.select, N_cart,
		NM.Cart, NM.Cart_coll, NM.omega2, NM.contr2fluct, axe1, naxe1,
		atoms1, natoms1, seq1, nres1, Ref_kin.atom_num, N_ref);
    Print_modes(N_print, nameout1, "Torsmodes", NM.select, naxe1,
		NM.Tors, NM.Tors_coll, NM.omega2, NM.contr2fluct, axe1, naxe1,
		atoms1, natoms1, seq1, nres1, Ref_kin.atom_num, N_ref);
    Print_modes(N_print, nameout1, "MWtorsmodes", NM.select, naxe1,
		NM.MW_Tors, NM.MW_Tors_coll, NM.omega2, NM.contr2fluct, axe1,
		naxe1, atoms1, natoms1, seq1, nres1, Ref_kin.atom_num, N_ref);
    printf("Printing normal modes. Time= %.2lf sec.\n", (clock()-t0)/nbtops);
    t0=clock();
  }

  // Print modes in PDB format
  if((PRINT_PDB)&&(N_MODE_PRINT)){
    //double RMSD=1.00, SDEV_SIM=RMSD*RMSD*Ref_kin.mass_tot;
    //double Coll_ave=0; for(ia=0; ia<NM.N; ia++)Coll_ave+=NM.Cart_coll[ia];
    //Coll_ave/=NM.N;
    int N_STEP=40, ip=0;
    for(ia=0; ia<NM.N; ia++){
      if((NM.contr2fluct[ia]==0)||(NM.select[ia]==0))continue;
      Print_mode_PDB(atoms1, natoms1, axe1, naxe1, bonds, seq1,
		     NM.Tors[ia], NM.omega[ia], N_STEP,
		     Para_simul, nameout1, ia, ip);
      ip++; if(ip==N_print)break;
    }
    printf("Printing modes as PDB. Time= %.2lf sec.\n", (clock()-t0)/nbtops);
    t0=clock();
  }

  /**********************  Binding sites dynamics *************************/
  Binding_site_dynamics(NM, Ref_kin, seq1, atoms1, nameout1,
			file_pdb1, chain1, Nchain, nres1, SITES);

  /**********************  Dynamical couplings ****************************/
  if(ALLOSTERY){
    printf("Predicting dynamical couplings\n");
    float *Confchange=NULL;
    if(CONF_CHANGE){
      // Compute conformation change over kinetic energy atoms
      Confchange=malloc(N_cart*sizeof(float));
      float coord_kin1[N_cart], coord_kin2[N_cart];
      Write_ref_coord_atom(coord_kin1, N_ref, atoms1, Ref_kin.atom_num);
      int atom_num2[natoms2];
      for(i=0; i<N_ref; i++)atom_num2[i]=atoms1[Ref_kin.atom_num[i]].ali;
      Write_ref_coord_atom(coord_kin2, N_ref, atoms1, atom_num2);
      rmsd=rmsd_mclachlan_f(coord_kin1, coord_kin2, Ref_kin.mass_atom, N_ref);
      for(i=0; i<N_ref; i++)Confchange[i]=coord_kin2[i]-coord_kin1[i];
    }
    Predict_allostery(NM, atoms1, Ref_kin, Int_list, N_int, seq1, nameout1,
		      Confchange, file_pdb1, chain1, nres1, SITES);
    printf("Dynamical coupling. Time= %.2lf sec.\n", (clock()-t0)/nbtops);
    t0=clock();
  }

 /******************** Simulations  ************************/
  if(Para_simul.N_SIMUL){
    int N_ens=2; //  LF_inf NoRot
    for(k=1; k<N_ens; k++){
      char name_ens[40]; float factor=-1;
      if(k==0){
	strcpy(name_ens,"MP"); factor=1.0;
      }else if(k==1){
	strcpy(name_ens,"NoRot"); factor=sqrt(slope_NoRot/slope);
      }
      if(factor<=0)continue;
      //Simulate_ensemble_Cart
      Simulate_ensemble(Para_simul.N_SIMUL, factor, name_ens,
			Para_confchange, atoms1, natoms1,
			axe1, naxe1, bonds, seq1, nres1, N_diso1, NM, J,
			Ref_kin, Int_list, N_int, INT_TYPE, s0, nameprot1);
    }
    printf("Drawing %d conformations from ensemble. Time= %.2lf sec.\n",
	   N_ens, (clock()-t0)/nbtops); t0=clock();
  }

  /******************** Example of Build up  ************************/
  /*if(BUILDUP){ // Example of application of build-up
    float fact=1.; int imode=0, nmove=10;
    Trajectory(atoms1,natoms1,axe1,naxe1,NM.Tors,imode,fact,nmove,bonds);
    }*/

  /**************  Computing conformation change given a force ********/
  if((FILE_FORCE!=NULL)&& (ANM==0)){
    float coord_ini[N_cart], coord_end[N_cart];
    Write_ref_coord_atom(coord_ini, N_ref, atoms1, Ref_kin.atom_num);
    char chain3=chain1[0];
    Force2Confchange(coord_end, FILE_FORCE, naxe1, N_ref, atoms1,
		     natoms1, Ref_kin.atom_num, J.Jacobian_ar, NM.omega2,
		     NM.Tors, NM.select, axe1, &chain3, nres1, seq1, bonds);
    rmsd=rmsd_mclachlan_f(coord_ini, coord_end, Ref_kin.mass_atom, N_ref);
    printf("rms force perturbed structure = %8.3f\n",rmsd);
  }

  /* Anharmonicity analysis
     int STEP_MAX=100;   // Number of steps for Move_struct or Move_all_modes
  if(0){ // It has to be corrected! 4/2/2013
    int step, moves;
    for(step=2; step<STEP_MAX; step++){
      moves=Move_all_modes(nameout1,axe1,naxe1,&NM,atoms1,natoms1,seq1,nres1,
			   atoms2, N_ref, Ref1.atom_num, Ref2.atom_num, step,
			   Para_simul, bonds);
      printf("%3d moves of all modes\n", moves);
      if(moves==0)break;
    }
    printf("Moving structure, all modes. Time= %.5lf sec.\n",
	   (clock()-t0)/nbtops); t0=clock();
	   }*/

  /*if(0 && CONF_CHANGE && PRINT_CONFCHANGE){
    printf("Simulating conformation change with normal modes\n");
    int MODE_MAX=50;    // Number of modes used for Move_struct
    float RMSD_STOP=0.1; // When Move_struct is stopped

    // Anharmonicity is computed here
    float rmsd_fin=rmsd;
    atom *atoms_sim=malloc(natoms1*sizeof(atom));
    for(i=0; i<natoms1; i++)atoms_sim[i]=atoms1[i];
    for(i=0; i<NM.N_relevant; i++)NM.Max_factor[i]=0;

    for(k=0; k<STEP_MAX; k++){
      int move=0; float rmsd_k=rmsd_fin;
      if(k){
	// WARNING: The matrix J is updated here
	J.N_kin=Compute_kinetic(&J,axe1,naxe1,atoms_sim,natoms1,Ref1);
      }
      for(i=0; i<MODE_MAX; i++){
	if(i>=NM.N_relevant)break;
	if(CONF_CHANGE){ia=NM.sort[i];}else{ia=i;}
	if((NM.contr2fluct[ia]==0)||(ia>=NM.N_relevant))continue;
	if(k){
	  Transform_tors_modes(NM.Tors[ia], NM.MW_Tors[ia],
			       J.T_sqrt_tr, J.T_sqrt_inv_tr,
			       N_modes, naxe1);
	  NM.Max_factor[ia]=0;
	}
	move+=Move_struct_confchange(atoms_sim, natoms1, &rmsd_fin,
				     nameout1, ia, 1, axe1, naxe1,
				     &NM, seq1, nres1, atoms2, N_ref,
				     Ref1.atom_num, Ref2.atom_num,
				     Para_simul, bonds);
	if(rmsd_fin < Para_simul.PDB_STEP)break;
      }
      printf("%2d round, %3d moves rmsd= %.2f\n", k+1, move, rmsd_fin);
      if((move==0)||(rmsd_fin < Para_simul.PDB_STEP))break;
      if(rmsd_k-rmsd_fin < RMSD_STOP)break;
    }
    free(atoms_sim);
    printf("Making conformation change. Time= %.5lf sec.\n",
	   (clock()-t0)/nbtops); t0=clock();
	   }*/

  /******************** Clean memory *************************/
  
  Clean_memory(NM, J, Hessian, naxe1, N_ref, N_cart, N_modes, ANM);
  Empty_Ref(&Ref_kin);
  
  
  return(0);
  
}

/******************  Other routines  ***************************/

/*********************** Handling memory  **************************/

void Allocate_memory(struct Normal_Mode *NM,
		     struct Jacobian *J,
		     float ***Hessian,
		     int N_axes, int N_ref, int N_cart,
		     int N_modes, int N_res)
{
  int i;

  // Hessian
  *Hessian=Allocate_mat2_f(N_modes, N_modes);
  printf("Hessian allocated\n");

  // Kinematics:
  Allocate_Jacobian(J, N_axes, N_cart);
  printf("Jacobian allocated\n");

  // Normal modes
  NM->N=N_modes;
  NM->N_kin=N_modes;
  NM->N_axes=N_axes;
  NM->N_cart=N_cart;
  NM->select=malloc(N_modes*sizeof(int));
  NM->omega=malloc(N_modes*sizeof(float));
  NM->omega2=malloc(N_modes*sizeof(float));
  NM->contr2fluct=malloc(N_modes*sizeof(float));
  NM->Cart=NULL;
  NM->Tors=Allocate_mat2_f(N_modes, N_axes);
  NM->MW_Tors=Allocate_mat2_f(N_modes, N_axes);
  NM->Cart_coll=malloc(N_modes*sizeof(float));
  NM->Tors_coll=malloc(N_modes*sizeof(float));
  NM->MW_Tors_coll=malloc(N_modes*sizeof(float));
  NM->Max_dev=malloc(N_modes*sizeof(float));
  NM->sort=malloc(N_modes*sizeof(int));
  NM->Tors_frac=malloc(N_modes*sizeof(float));
  for(i=0; i<N_modes; i++)NM->Tors_frac[i]=1.0;
  NM->tors_fluct=NULL;
  NM->cart_fluct=NULL;
  NM->confchange2=malloc(N_modes*sizeof(float));
  NM->Anharmonicity=malloc(N_modes*sizeof(float));
  NM->Anharm_struct=malloc(N_modes*sizeof(float));
  for(i=0; i<N_modes; i++){
    NM->Anharmonicity[i]=0; NM->Anharm_struct[i]=0;
  }
  NM->Max_factor=malloc(N_modes*sizeof(float));
  NM->Max_RMSD=malloc(N_modes*sizeof(float));
  for(i=0; i<N_modes; i++)NM->Max_RMSD[i]=-1;
  printf("Normal modes allocated\n");

}

void Clean_memory(struct Normal_Mode NM,
		  struct Jacobian J,
		  float **Hessian,
		  int N_axes, int N_ref, int N_cart,
		  int N_modes, int ANM)
{

  // Free structure 1
  // free(axe1);
  // free(atoms1);

  // Free Hessian
  Empty_matrix_f(Hessian, N_modes);


  // Cleaning normal modes
  if(ANM==0){Empty_matrix_f(NM.Cart, NM.N_relevant);}
  else{Empty_matrix_f(NM.Cart, NM.N);}
  Empty_matrix_f(NM.Tors, NM.N);
  Empty_matrix_f(NM.MW_Tors, NM.N);
  free(NM.omega2);
  free(NM.omega);
  free(NM.contr2fluct);
  free(NM.Cart_coll);
  free(NM.Tors_coll);
  free(NM.MW_Tors_coll);
  free(NM.Tors_frac);
  free(NM.sort);
  free(NM.Anharmonicity);
  free(NM.Anharm_struct);
  free(NM.Max_factor);
  free(NM.Max_RMSD);
  free(NM.cart_fluct);
  free(NM.tors_fluct);
  free(NM.confchange2);

  // Cleaning reference set for kinetic energy
  Empty_Jacobian(J);

}


/*************************   Printing  *************************/

void Print_summary(double *Mean_Cart_coll,
		   char *name_out, char *name1, char *parameters, int Nchain,
		   struct Normal_Mode NM,
		   float r_B, float RMSD_crys, float RMSD_NM,
		   float kappa, float *f_dof,
		   struct axe *axes, int N_axes, int N_main,
		   int Nskip, int N_atoms, int N_res, int N_diso,
		   int N_int, int N_inter, float Cont_overlap,
		   float Tors_fluct)
{
  FILE *file_out;
  int ia,i;

  printf("Writing %s\n", name_out);
  file_out=fopen(name_out, "w");

  fprintf(file_out, "%s\n", parameters);
  fprintf(file_out, "protein               %s\n", name1);
  fprintf(file_out, "Nchain                %d\n", Nchain);
  fprintf(file_out, "Nres                  %d\n", N_res);
  fprintf(file_out, "Degrees of freedom    %d\n", NM.N);
  fprintf(file_out, "Side chain            %d\n", N_axes-N_main);
  fprintf(file_out, "Skipped main chain    %d\n", Nskip);
  fprintf(file_out, "Disordered gaps       %d\n", N_diso);
  fprintf(file_out, "Native interactions   %d\n", N_int);
  if(Cont_overlap >= 0)
    fprintf(file_out, "Overlap with MIN int. %.3f\n", Cont_overlap);

  double k_Therm=Collectivity_norm1(NM.contr2fluct, NM.N); //Renyi
  fprintf(file_out, "Recp.Coll(therm)      %.0f\n", k_Therm);
  /*fprintf(file_out, "Area(therm)           %.3f\n",
    Area_norm1(NM.contr2fluct, NM.N));*/
  double Mean_coll=0, sum_w=0;
  for(ia=0; ia<NM.N; ia++){
    float w=NM.contr2fluct[ia];
    Mean_coll+=NM.Cart_coll[ia]*w; sum_w+=w;
  }
  *Mean_Cart_coll=Mean_coll/sum_w;
  fprintf(file_out, "Ave_collectivity_NM   %.3f\n", *Mean_Cart_coll);
  Coll_thr_cc=*Mean_Cart_coll*0.6666;
  int N_modes_coll=0;
  for(ia=0; ia<NM.N; ia++){
    if((NM.select[ia])&&(NM.Cart_coll[ia] >= Coll_thr_cc))N_modes_coll++;
  }
  fprintf(file_out, "Num.collective_modes  %d\n", N_modes_coll);
  fprintf(file_out, "Minimal_collectivity  %.3f\n", Coll_thr_cc);

  // Harmonic entropy
  double entropy=0;
  for(i=0; i<NM.N; i++)if(NM.omega[i]>0)entropy+=log(NM.omega[i]);
  entropy/=NM.N; entropy=(1.+log(2*3.14159))/2.-entropy;
  fprintf(file_out, "Entropy per d.o.f.    %.3f\n", entropy);

  fprintf(file_out, "r(B_pred,B_exp)       %.3f\n", r_B);
  fprintf(file_out, "Force constant        %.1f\n", kappa);
  fprintf(file_out, "RMSD_crystal          %.3f\n", RMSD_crys);
  fprintf(file_out, "RMSD_Norm.Modes       %.3f\n", RMSD_NM);
  fprintf(file_out, "Torsional_RMSD        %.3f\n", Tors_fluct);
  fprintf(file_out, "Internal_fluct        %.3f\n", f_dof[0]);
  fprintf(file_out, "Translation_fluct     %.3f\n", f_dof[1]);
  fprintf(file_out, "Rotation_fluct        %.3f\n", f_dof[2]);

  // Rigid body degrees of freedom
  if(Nchain>1){
    fprintf(file_out, "Interchain contacts    %d\n", N_inter);
    double tra=0, rot=0, all=0;
    for(ia=0; ia<NM.N; ia++){
      float *v=NM.MW_Tors[ia];
      double tra_ia=0, rot_ia=0;
      for(i=0; i<N_main; i++){
	if(axes[i].rigid){
	  if(axes[i].type=='l'){tra_ia+=(*v)*(*v);}
	  else{rot_ia += (*v)*(*v);}
	}
	v++;
      }
      tra+=tra_ia*NM.contr2fluct[ia];
      rot+=rot_ia*NM.contr2fluct[ia];
      all+=NM.contr2fluct[ia];
    }
    fprintf(file_out, "Fraction internal tra %.3f\n", tra/all);
    fprintf(file_out, "Fraction internal rot %.3f\n", rot/all);
  }

  fprintf(file_out, "#\n");
  fclose(file_out);
}

/***************************  Input **********************************/

int getArgs(int argc, char **argv,
	    char *file_pdb1, char *chain1,
            char *file_pdb2, char *chain2,
	    int *ANM, char *REF,
	    int *SIDECHAINS, int *OMEGA, int *PSI,
	    float *K_OMEGA, float *K_PSI,
	    float *K_PHI, float *K_CHI,
	    float *K_BA, float *K_BL,
	    float *E_MIN, float *COLL_THR,
	    int *MIN_INT, char *INT_TYPE,
	    float *C_THR, int *S_TYPE, float *S_THR,
	    int *ONEINT, int *N_RESRES,
	    int *N_MODE, char *outdir,
	    int *PRINT_CONFCHANGE, int *PRINT_FORCE,
	    int *PRINT_PDB, int *PRINT_MODE_SUMM,
	    char **FILE_FORCE, int *ALLOSTERY,
	    float *KAPPA, int *FIT_B,
	    float *RMSD_MIN, int *NMUT,
	    struct Para_simul *Para_simul,
	    struct Para_confchange *Para_confchange,
	    float *SEQID_THR,
	    char *parameters,
	    int *PRINT_COV_COUPLING,
	    int *PRINT_DEF_COUPLING,
	    int *PRINT_DIR_COUPLING,
	    int *PRINT_COORD_COUPLING,
	    int *PRINT_SIGMA_DIJ,
	    char *PROF_TYPE,
	    int *ALL_PAIRS, float *SIGMA,
	    int *STRAIN, char *SITES,
	    int *PRINT_CMAT, int *FORCE_STAB)
{
  int i; //p1=0, p2=0, out=0


  /************** Initialize ****************/
  // Input
  file_pdb1[0]='\0'; strcpy(chain1, "");
  file_pdb2[0]='\0'; strcpy(chain2, "");
  // Model variables
  *ANM=0;  *C_THR=0;
  INT_TYPE[0]='\0'; REF[0]='\0';
  EXP_HESSIAN=EXP_HESSIAN_DEF;
  *MIN_INT=MIN_INT_DEF;
  *K_PSI=K_PSI_DEF;
  *K_PHI=K_PHI_DEF;
  *K_CHI=K_CHI_DEF;
  *K_OMEGA=K_OMEGA_DEF;
  DA_THR=DA_THR_DEF;
  COS_DAA=COS_DAA_DEF;
  ENE_HB=ENE_HB_DEF;
  KINETIC=1;
  // Output
  *N_MODE=0;

  // Analysis of conformation change
  Para_confchange->RMSD_THR=RMSD_THR_DEF; // Minimum confchange per mode
  Para_confchange->COLL_THR=COLL_THR_DEF; // Threshold on collectivity
  *SEQID_THR=SEQID_THR_DEF;

  // Simulations
  Para_simul->N_SIMUL=0;
  Para_simul->AMPLITUDE=AMPLITUDE_DEF;
  Para_simul->D_REP=D_REP_DEF;
  Para_simul->E_THR=E_THR_DEF;
  Para_simul->PDB_STEP=PDB_STEP_DEF;
  Para_simul->MAX_ANGLE=MAX_ANGLE_DEF;
  Para_simul->RESET=0;
  Para_simul->SELECT_ENE=0;
  // Conformation changes
  Para_simul->NSTEPS=100;
  Para_simul->STEP_MAX=0.5;
  Para_simul->STEP_MIN=0.001;
  Para_simul->ANGLE=0.1;

  if(argc<2)help();
  int infile=Read_para(argv[1], file_pdb1, chain1,file_pdb2, chain2,
		       ANM, REF, SIDECHAINS, OMEGA, PSI,
		       K_OMEGA, K_PSI, K_PHI, K_CHI, K_BA, K_BL,
		       E_MIN, COLL_THR, MIN_INT, INT_TYPE, C_THR,
		       S_TYPE, S_THR, ONEINT, N_RESRES,
		       N_MODE, outdir, PRINT_CONFCHANGE, PRINT_FORCE,
		       PRINT_PDB, PRINT_MODE_SUMM, FILE_FORCE, ALLOSTERY,
		       KAPPA, FIT_B, RMSD_MIN, NMUT, Para_simul,
		       Para_confchange, SEQID_THR,
		       PRINT_COV_COUPLING, PRINT_DEF_COUPLING,
		       PRINT_DIR_COUPLING, PRINT_COORD_COUPLING,
		       PRINT_SIGMA_DIJ, PROF_TYPE, ALL_PAIRS, SIGMA,
		       STRAIN, SITES, PRINT_CMAT, FORCE_STAB);
  if(infile)goto inform;
  printf("WARNING, input file not specified or absent (%s)\n", argv[1]);
  printf("WARNING, reading parameters from command line\n");

  for(i=1; i<argc; i++){
      // Proteins:
    if (strncmp(argv[i],"-p2",3)==0){
      i++; if(i>=argc)continue;
      strcpy(file_pdb2,argv[i]); //p2=1;
      printf("file_pdb2=%s\n",file_pdb2);
    }else if (strncmp(argv[i],"-c2",3)==0){
      i++; if(i>=argc)continue;
      if((strncmp(argv[i], "all", 3)==0)||(strncmp(argv[i], "ALL",3)==0))
	{*chain2='*';}
      else{strcpy(chain2,argv[i]);}
      printf("chain2=%s\n",chain2);
    }else if (strncmp(argv[i],"-p1",3)==0){
      i++; if(i>=argc)continue;
      strcpy(file_pdb1,argv[i]); //p1=1;
      printf("file_pdb1=%s\n",file_pdb1);
    }else if (strncmp(argv[i],"-c1",3)==0){
      i++; if(i>=argc)continue;
      if((strncmp(argv[i], "all",3)==0)||(strncmp(argv[i], "ALL",3)==0))
	{*chain1='*';}
      else{strcpy(chain1,argv[i]);}
      printf("chain(s) to read: %s\n",chain1);

      // Model:
    }else if (strncmp(argv[i],"-anm",4)==0){
      *ANM=1;
    }else if (strncmp(argv[i],"-hnm",4)==0){
      *ANM=1; HNM=1;
    }else if (strncmp(argv[i],"-sc",3)==0){
      *SIDECHAINS=1;
    }else if (strncmp(argv[i],"-omega",6)==0){
      *OMEGA=1;
    }else if (strncmp(argv[i],"-ref",4)==0){
      i++; if(i>=argc)continue;
      strcpy(REF, argv[i]);
    }else if (strncmp(argv[i],"-cont_type",10)==0){
      i++; if(i>=argc)continue;
      strcpy(INT_TYPE, argv[i]);
    }else if (strncmp(argv[i],"-expo", 5)==0){
      i++; if(i>=argc)continue;
      sscanf(argv[i], "%f", &EXP_HESSIAN);
    }else if (strncmp(argv[i],"-cont_thr",9)==0){
      i++; if(i>=argc)continue;
      sscanf(argv[i], "%f", C_THR);
      printf("Threshold distance= %.1f\n", *C_THR);
    }else if (strncmp(argv[i],"-nokin",6)==0){
      KINETIC=0;

      // Force
    }else if (strncmp(argv[i],"-force",6)==0){
      i++; if(i>=argc)continue;
      *FILE_FORCE=malloc(400*sizeof(char));
      strcpy(*FILE_FORCE, argv[i]);
      // Simulation
    }else if (strncmp(argv[i],"-simul",6)==0){
      i++; if(i>=argc)continue;
      sscanf(argv[i], "%d", &(Para_simul->N_SIMUL));
      printf("Simulations to be done= %d\n", Para_simul->N_SIMUL);
      // Output:
    }else if (strncmp(argv[i],"-outdir",7)==0){
      i++; if(i>=argc)continue;
      strcpy(outdir, argv[i]); //out=1;
      printf("output directory= %s\n",outdir);
    }else if (strncmp(argv[i],"-modes",6)==0){
      i++; if(i>=argc)continue;
      *N_MODE=atoi(argv[i]);  //sscanf(argv[i], "%d", N_MODE);
      printf("%d normal modes to be printed\n",*N_MODE);
    }else if (strncmp(argv[i],"-print_pdb",10)==0){
      *PRINT_PDB=1;
    }else if (strncmp(argv[i],"-allostery",8)==0){
      *ALLOSTERY=1;
    }else if (strncmp(argv[i],"-print_confchange",13)==0){
      *PRINT_CONFCHANGE=1;
    }else if (strncmp(argv[i],"-print_force",12)==0){
      *PRINT_FORCE=1;
    }else if (strncmp(argv[i],"-print_summ",11)==0){
      *PRINT_MODE_SUMM=1;
    }else if (strncmp(argv[i],"-debug",6)==0){
      DEBUG=1;
    }else if (strncmp(argv[i],"-h",2)==0){
      help();
    }else if (argv[i][0]=='-'){
      printf("WARNING, argument %s does not exist\n", argv[i]);
    }
  }

 inform:
  if(*SEQID_THR > 1.0)(*SEQID_THR)/=100;
  /*if(*SEQID_THR > 1.0)
    printf("WARNING, SEQID_THR=%.2f > 1, performing Mammoth alignment\n",
    *SEQID_THR);*/

  if(file_pdb1[0]=='\0'){
    printf("ERROR, at least one PDB file is mandatory\n");
    help();
  }
  if(*OMEGA>0){
    printf("Omega angle taken as degree of freedom.\n");
  }else if(*OMEGA<0){
    printf("Omega angle taken as dof if Domega>%d degrees.\n", D_omega_thr);
  }else{
    *K_OMEGA=0;
  }
  if(*PSI==0){
    printf("Psi angle frozen\n"); *K_PSI=0;
  }
  if(*SIDECHAINS){
    printf("Side chains degrees of freedom used\n");
    if((strncmp(INT_TYPE, "MIN", 3)!=0)||(strncmp(INT_TYPE, "SCR", 3)!=0)){
      printf("WARNING, interaction type %s not allowed with side chains\n",
	     INT_TYPE);
      strcpy(INT_TYPE, "MIN");
    }
    if((strncmp(REF, "ALL", 3)!=0)){
      printf("WARNING, reference atoms %s not allowed with side chains\n",
	     REF);
      strcpy(REF, "ALL");
    }
    printf("Reference atoms set to %s, interaction type set to %s\n",
	   REF, INT_TYPE);
    printf("Minimum number of interactions for accepting a degree of freedom");
    printf(": %d\n", *MIN_INT);
  }else{
    *K_CHI=0;
  }
  if((strncmp(INT_TYPE, "CA", 2)!=0)&&
     (strncmp(INT_TYPE, "CB", 2)!=0)&&
     (strncmp(INT_TYPE, "SCA", 3)!=0)&&
     (strncmp(INT_TYPE, "SCB", 3)!=0)&&
     (strncmp(INT_TYPE, "MIN", 3)!=0)&&
     (strncmp(INT_TYPE, "HYD", 3)!=0)&&
     (strncmp(INT_TYPE, "ALL", 3)!=0)&&
     (strncmp(INT_TYPE, "SCR", 3)!=0)&&
     (strncmp(INT_TYPE, "SHA", 3)!=0)&&
     (strncmp(INT_TYPE, "HB", 2)!=0)){
    if(INT_TYPE[0]!='\0')
      printf("WARNING, interaction type %s does not exist\n", INT_TYPE);
    printf("Interaction type set to default %s\n", INT_TYPE_DEF);
    strcpy(INT_TYPE, INT_TYPE_DEF);
  }else{
    printf("Contact type set to %s\n", INT_TYPE);
    if(strncmp(INT_TYPE, "HB", 2)==0){
      printf("Estimating hydrogen bonds, ");
      printf("Min.dist= %.3f max.cos(DAA')= %.3f Force factor= %.3f\n",
	     DA_THR, COS_DAA, ENE_HB);
    }
  }

  if(REF[0]!='\0'){
    if((strncmp(REF, "CA", 2)!=0)&&
       (strncmp(REF, "CB", 2)==0)&&
       (strncmp(REF, "BB", 2)==0)&&
       (strncmp(REF, "EB", 2)==0)&&
       (strncmp(REF, "ALL", 3)==0)){
      printf("WARNING, %s are not allowed reference atoms\n", REF);
      REF[0]='\0';
    }
  }
  if(EXP_HESSIAN<0){
    printf("ERROR, exponent must be positive (%.3f), setting it to zero\n",
	   EXP_HESSIAN); EXP_HESSIAN=0;
  }else if (EXP_HESSIAN){
    printf("Exponent of force constant = %.3f\n", EXP_HESSIAN);
  }


  if(*C_THR==0){
    if(strncmp(INT_TYPE, "CA", 2)==0){
      *C_THR=THR_CA;
    }else if(strncmp(INT_TYPE, "CB", 2)==0){
      *C_THR=THR_CB;
    }else if(strncmp(INT_TYPE, "SCB", 3)==0){
      *C_THR=THR_ALL;
    }else if(strncmp(INT_TYPE, "ALL", 3)==0){
      *C_THR=THR_ALL;
    }else if(strncmp(INT_TYPE, "MIN", 3)==0){
      *C_THR=THR_ALL;
    }else if(strncmp(INT_TYPE, "HYD", 3)==0){
      *C_THR=THR_ALL;
    }else if(strncmp(INT_TYPE, "SCR", 3)==0){
      *C_THR=THR_CA;
    }else if(strncmp(INT_TYPE, "HB", 2)==0){
      *C_THR=THR_ALL;
    }else{
      printf("ERROR, wrong interaction type %s\n", INT_TYPE);
      exit(8);
    }
    printf("Contact threshold set to default %.1f\n", *C_THR);
  }

  if(*ANM){
    printf("Degrees of freedom: Cartesian (ANM)\n");
    if(REF[0]!='\0')
      printf("WARNING, reference atoms can not be assigned in the ANM\n");
  }else{
    printf("Degrees of freedom: Torsional (TNM, default)\n");
  }

  sprintf(parameters, "Para: REF=%s Sidechain=%d Min_int=%d Omega=%d Psi=%d",
	  REF, *SIDECHAINS, *MIN_INT, *OMEGA, *PSI);
  sprintf(parameters,
	  "%s  K_O=%.1f K_F=%.1f K_P=%.1f K_C=%.1f K_BA=%.1f K_BL=%.1f",
	  parameters, *K_OMEGA, *K_PHI, *K_PSI, *K_CHI, *K_BA, *K_BL);
  sprintf(parameters,"%s CONT=%s ", parameters, INT_TYPE);
  if(strncmp(INT_TYPE, "SCR", 3)==0){
    sprintf(parameters, "%s Tolerance=%.2f THR=%.1f",
	    parameters, *S_THR, *C_THR);
  }else if(strncmp(INT_TYPE, "SHA", 3)==0){
    sprintf(parameters, "%s type=%d d=%.2f THR=%.1f",
	    parameters, *S_TYPE, *S_THR, *C_THR);
  }else{
    sprintf(parameters, "%s thr=%.2f", parameters, *C_THR);
  }
  sprintf(parameters,
	  "%s EXPO=%.1f KAPPA=%.1f COLL_THR=%.0f",
	  parameters, EXP_HESSIAN, *KAPPA, *COLL_THR/3);

  fflush(stdout);
  return (0);
}

void help(void)
{
  fprintf(stderr, "Program %s\n", PRG);
  fprintf(stderr, "author Ugo Bastolla <ubastolla@cbm.csic.es> ");
  fprintf(stderr, "Centro de Biologia Molecular Severo Ochoa (CSIC-UAM)\n");
  fprintf(stderr, "Computes normal modes of proteins with the TNM or ANM.\n");
  fprintf(stderr, "If two structures are provided, it projects the ");
  fprintf(stderr, "experimental conformation change over normal modes\n");
  fprintf(stderr, "Inputs can be given either by file or by command line\n");
  fprintf(stderr, "   USAGE:");
  fprintf(stderr, "   %s <inputile>  or\n", PRG);
  fprintf(stderr, "   %s -p1 <pdbfile1>", PRG);
  fprintf(stderr, "   (reference structure for computing normal modes)\n");
  fprintf(stderr, "   OPTIONS:\n");
  fprintf(stderr, "       -h prints this help\n");
  fprintf(stderr, "       -c1 <chain_id1> <all>:reading all chains, A, AB..\n");
  fprintf(stderr, "       -p2 <pdbfile2> for conformation change\n");
  fprintf(stderr, "       -c2 <chain_id2> <all>:reading all chains, A, AB..\n");
  fprintf(stderr, "       -ref Reference atoms. Allowed: CA CB BB EB ALL. ");
  fprintf(stderr, "       -omega  Use also omega angle as degree of freedom\n");
  fprintf(stderr, "Default: %s\n", REF_DEF);
  fprintf(stderr, "       -anm use ANM d.o.freedom (by default TNM is used)\n");
  fprintf(stderr, "Interaction model:\n");
  fprintf(stderr, "       -cont_type Contact type CA CB, ALL, MIN HYD or HB. ");
  fprintf(stderr, "Default: %s\n", INT_TYPE_DEF);
  fprintf(stderr, "        if -cont_type=HB hydrogen bonds are estimated\n");
  fprintf(stderr, "       -cont_thr Distance threshold default %.1f\n",THR_CB);
  fprintf(stderr, "       -expo <e> k~r^(-e) Default 0\n");
  fprintf(stderr, "       -hnm HNM (ref=CA, cont_type=CA, e=6, covalent)\n");
  fprintf(stderr, "       -debug  print debugging information\n");
  fprintf(stderr, "       -outdir <output_directory>\n");
  fprintf(stderr, "       -modes <number of modes printed>\n");
  fprintf(stderr, "       -print_pdb    Print modes in PDB format\n");
  fprintf(stderr, "       -print_summ   Print modes summary\n");
  fprintf(stderr, "       -print_confchange Print conformation change\n");
  fprintf(stderr, "       -print_force  Print force induced by c.change\n");
  fprintf(stderr, "       -force        PDB file with force as coordinates\n");
  fprintf(stderr, "       -simul        <Num. simulated structures>\n");
  fprintf(stderr, "       -allostery Predict allostery\n");
  fprintf(stderr, "\n");
  fprintf(stderr, "FORMAT of input file:\n");
  fprintf(stderr, "####   INPUT:\n");
  fprintf(stderr, "PDB1= /data/ortizg/databases/pdb/1usg.pdb ");
  fprintf(stderr, "! Reference structure\n");
  fprintf(stderr, "CH1=  A                                   ");
  fprintf(stderr, "! Chain\n");
  fprintf(stderr, " Conformation change (optional):\n");
  fprintf(stderr, "PDB2= /data/ortizg/database/pdb/1usk.pdb");
  fprintf(stderr, "! Conformation change\n");
  fprintf(stderr, "CH2=  A                                  ");
  fprintf(stderr, "! Chain\n");
  fprintf(stderr, "#\n");
  fprintf(stderr, "####  Model parameters (reccomended: do not change)\n");
  fprintf(stderr,
	  "#===============================================================\n");
  fprintf(stderr, "DOF=  TORS  CART			    ");
  fprintf(stderr, "! Degrees of freedom\n");
  fprintf(stderr, "REF=  EB CB  CA BB ALL                   ");
  fprintf(stderr, "! Reference atoms\n");
  fprintf(stderr, "SIDECHAIN=0                              ");
  fprintf(stderr, "! Use sidechains as degree of freedom?\n");
  fprintf(stderr,
	  "# This option allows using side chains chi angles as additional degree of\n");
  fprintf(stderr,
	  "# freedom, but introduces non collective motions that worsen performances.\n");
  fprintf(stderr, "MIN_INT=1                              ");
  fprintf(stderr, "! Min. number of interactions to accept a dof\n");
  fprintf(stderr, "E_MIN=0.00001                              ");
  fprintf(stderr, "! Min. eigenvalue/<evalue> of a normal mode\n");
  fprintf(stderr, "COLL_THR=30                                ");
  fprintf(stderr, "! Discard modes with # modev atoms < COLL_THR\n");
  fprintf(stderr, "OMEGA=0                                  ");
  fprintf(stderr, "! Use omega angle as degree of freedom? (def No)\n");
  fprintf(stderr, "PSI=1                                  ");
  fprintf(stderr, "! Use psi angle as degree of freedom? (Def yes)\n");
  fprintf(stderr, "K_BL=%.2f                                ", K_BA);
  fprintf(stderr, "! Elastic constant for bond lengths\n");
  fprintf(stderr, "K_BA=%.2f                                ", K_BA);
  fprintf(stderr, "! Elastic constant for bond angles\n");
  fprintf(stderr, "K_OMEGA=%.2f                             ", K_OMEGA);
  fprintf(stderr, "! Elastic constant for angle omega\n");
  fprintf(stderr, "K_PHI=%.2f                                ", K_PHI);
  fprintf(stderr, "! Elastic constant for angle phi\n");
  fprintf(stderr, "K_PSI=%.2f                                ", K_PSI);
  fprintf(stderr, "! Elastic constant for angle psi\n");
  fprintf(stderr, "K_CHI=%.1f                                ", K_CHI);
  fprintf(stderr, "! Elastic constant for angle Chi\n");
  fprintf(stderr, "CONT_TYPE= MIN ");
  fprintf(stderr, "! Interaction model (MIN SCR SHA SCB CB CA HB HNM)\n");
  fprintf(stderr, "CONT_THR=  5.0            ");
  fprintf(stderr, "! Threshold for contacts\n");
  fprintf(stderr, "S_THR= 0.2                          ");
  fprintf(stderr, "! Parameter for screened or shadow interactions\n");
  fprintf(stderr, "S_TYPE= 0.2                             ");
  fprintf(stderr, "! Type of shadow interactions\n");
  fprintf(stderr, "# 0=angle 1=axis distance 2=S-ball-axis-distance\n");
  fprintf(stderr, "ONEINT= 1                             ");
  fprintf(stderr, "! Only one interaction per residue pair?\n");
  fprintf(stderr, "N_RESRES= 1                           ");
  fprintf(stderr, "! Max num interactions per residue pair\n");
  fprintf(stderr, "EXP_HESSIAN= 0                           ");
  fprintf(stderr, "! Force constant k~r^(-e)\n");
  fprintf(stderr, "FIT_B= 1                            ");
  fprintf(stderr, "! Fit B factors if present? (default YES)\n");
  fprintf(stderr, "KAPPA= 218.4                        ");
  fprintf(stderr, "! force constant when not fitting B factors\n");
  fprintf(stderr, "###  Analysis of conformation change\n");
  fprintf(stderr, "RMSD_MIN= 0.5                            ");
  fprintf(stderr, "! Min. RMSD for analyzing conformation change\n");
  fprintf(stderr, "NMUT= -1                            ");
  fprintf(stderr, "! Required num of mutations between two proteins\n");
  fprintf(stderr, "                                    ");
  fprintf(stderr, "! NMUT=-1: No requirement\n");
  fprintf(stderr, "MUT_FORCE= 1  ");
  fprintf(stderr, "! 1: Build mutation based on change of stability ");
  fprintf(stderr, "0: Build mutation based on change of size\n");

  fprintf(stderr, "RMSD_THR= 0.2                            ");
  fprintf(stderr, "! Smallest RMSD produced by relevant modes\n");
  fprintf(stderr, "SEQID_THR= 50                            ");
  fprintf(stderr, "! Below this identity, perform struct.alignment\n");
  fprintf(stderr, "#\n");
  fprintf(stderr, "#### General output\n");
  fprintf(stderr,
	  "#==================================================================\n");
  fprintf(stderr, "NMODES= 5                                ");
  fprintf(stderr, "! Number of modes to print\n");
  fprintf(stderr, "PRINT_PDB= 0                             ");
  fprintf(stderr, "! Print modes as PDB files?\n");
  fprintf(stderr, "PRINT_CONT_MAT=0                         ");
  fprintf(stderr, "! Print Contact matrix?");
  fprintf(stderr, "PRINT_SUMM= 1                            ");
  fprintf(stderr, "! Print summary of results\n");
  fprintf(stderr, "PRINT_CHANGE= 0                          ");
  fprintf(stderr, "! Print conformation change?\n");
  fprintf(stderr, "STEP_MAX= 0.5                            ");
  fprintf(stderr, "! Max. step in confchange\n");
  fprintf(stderr, "STEP_MIN= 0.001                          ");
  fprintf(stderr, "! Smallest step in confchange\n");
  fprintf(stderr, "NSTEPS= 100                              ");
  fprintf(stderr, "! Number of steps in confchange\n");
  fprintf(stderr, "ANGLE= 0.1                               ");
  fprintf(stderr, "! Angular step in confchange\n");


  fprintf(stderr, "PRINT_FORCE= 0                           ");
  fprintf(stderr, "! Print force from linear response\n");
  fprintf(stderr, "#FILE_FORCE= \n");
  fprintf(stderr, "! File with force, compute deformation\n");
  fprintf(stderr, "#\n");
  fprintf(stderr, "DEBUG= 0                                 ");
  fprintf(stderr, "! Print debugging information\n");

  fprintf(stderr, "#### Dynamical couplings\n");
  fprintf(stderr,
	  "#==================================================================\n");
  fprintf(stderr, "ALLOSTERY=0                              ");
  fprintf(stderr, "! Compute dynamical couplings\n");
  fprintf(stderr, "ALL_PAIRS=0         ! Print couplings for all pairs? (1=YES)\n");
  fprintf(stderr, "SIGMA=1.0           ! If ALL_PAIRS=0, couplings are printed\n");
  fprintf(stderr, "# only for pairs with Coupling_ij > SIGMA*Std.dev\n");
  fprintf(stderr, "PROF_TYPE= C        ! Type of profile of the couplings p_i({C_kl})\n");
  fprintf(stderr, "# A=average E=effective connectivity P=principal eigenvector\n");
  fprintf(stderr, "PRINT_COV_COUPLING=0                    ");
  fprintf(stderr, "! Print covariance couplings\n");
  fprintf(stderr, "PRINT_DEF_COUPLING=0                    ");
  fprintf(stderr, "! Print deformation couplings\n");
  fprintf(stderr, "# Allosteric coupling A_ij is the deformations produced on site j by an\n");
  fprintf(stderr, "# unitary force applied in j in the direction that maximizes the deformation.\n");
  fprintf(stderr, "# The coupling is output only when it is > SIGMA standard deviations above the mean value.\n");
  fprintf(stderr, "# Output file: <>_deformation_coupling.dat\n");
  fprintf(stderr, "PRINT_DIR_COUPLING= 0	! Print directionality couplings\n");
  fprintf(stderr, "# Directionality coupling D_ij is the Boltzmann average of the scalar\n");
  fprintf(stderr, "# product of the direction of motion of the residues i and j. If it is\n");
  fprintf(stderr, "# positive the two residues tend to move in the same direction.\n");
  fprintf(stderr, "# The coupling is output only when it is > SIGMA standard deviations above\n");
  fprintf(stderr, "# Output file: <>_directionality_coupling.dat and\n");
  fprintf(stderr, "# <>_directionality_coupling_neg.dat (< -SIGMA standard deviations)\n");
  fprintf(stderr, "# It is output in the format of a N*N matrix for all pairs of sites\n");
  fprintf(stderr, "# Output file: <>_directionality_matrix.dat\n");
  fprintf(stderr, "PRINT_COORD_COUPLING=0			  ! Print coordination couplings\n");
  fprintf(stderr, "# Coordination coupling C_ij is the Boltzmann average of the squared\n");
  fprintf(stderr, "# fluctuations of the distance d_ij with respect to the equilibrium value.\n");
  fprintf(stderr, "# If it is small the two residues maintain an almost fixed distance during\n");
  fprintf(stderr, "# their dynamics.\n");
  fprintf(stderr, "# The coupling is output only when it is > SIGMA standard deviations above\n");
  fprintf(stderr, "# the mean value.\n");
  fprintf(stderr, "# Output file: <>_coordination_coupling.dat\n");
  fprintf(stderr, "PRINT_SIGMA_DIJ=0   ! Print variance of interatomic distance (only CA atoms)\n");
  fprintf(stderr, "# Note that it is the square of the coordination coupling\n");
  fprintf(stderr, "# Output file: <>_interatomic_distance_variance.dat");
  fprintf(stderr, "SITES=leut_sites.in	! File where an active site is read.\n");
  fprintf(stderr, "# If not specified, read from the SITE record in the PDB file.\n");
  fprintf(stderr, "# format: SITE AA (3 letter) CHAIN RESNUM (PDB)\n");
  fprintf(stderr, "# The mean coupling of pairs of residues in the active site is computed.\n");
  fprintf(stderr, "#\n");
  fprintf(stderr, "#### Generation of alternative structures\n");
  fprintf(stderr, "#==================================================================\n");
  fprintf(stderr, "SIMUL=4		     ! Number of simulated structures\n");
  fprintf(stderr, "PDB_STEP=0.5              ! Minimum Rmsd between structures printed as PDB\n");
  fprintf(stderr, "AMPLITUDE=1.0             ! Amplitude applied to normal modes\n");
  fprintf(stderr, "E_THR=5.0                 ! Maximum allowed energy of generated structures\n");
  fprintf(stderr, "D_REP=2.5                 ! Maximum distance for computing repulsion energy\n");
  fprintf(stderr, "\n");
  exit(1);
}

void GetPdbId(char *pdb_file_in, char *pdbid){
     /* This subroutine pretends to get the
        PDB id from a pdb file name, and ressembles
	quite a lot my "old-and-dirty-Perl" days */

  int start=0, end=0, i,j; //end2=0

  for(i=strlen(pdb_file_in)-1;i>=0;i--){
    if (pdb_file_in[i]=='.'){
      end=i-1;
    }else if (pdb_file_in[i]=='/'){
      start=i+1; //end2=i-1;
      break;
    }
  }
  j=0;
  for (i=start;i<=end;i++){
    pdbid[j]=pdb_file_in[i];
    j++;
  }
  pdbid[j]='\0';
}

void Copy_vector(float *xx, float *yy, int n){
  int i; float *x=xx, *y=yy;
  for(i=0; i<n; i++){*x=*y; x++; y++;}
}

void Write_ref_coord_d(double *coords, int N_ref, atom *atoms, int *atom_num)
{
  double *coord=coords;
  for(int i=0; i<N_ref; i++){
    double *r=atoms[atom_num[i]].r;
    for(int j=0; j<3; j++){*coord=*r; coord++; r++;}
  }
}

int Read_para(char *filename,
	      char *file_pdb1, char *chain1,
	      char *file_pdb2, char *chain2,
	      int *ANM, char *REF,
	      int *SIDECHAINS, int *OMEGA, int *PSI,
	      float *K_OMEGA, float *K_PSI,
	      float *K_PHI, float *K_CHI,
	      float *K_BA, float *K_BL,
	      float *E_MIN, float *COLL_THR, int *MIN_INT,
	      char *INT_TYPE, float *C_THR,
	      int *S_TYPE, float *S_THR,
	      int *ONEINT, int *N_RESRES,
	      int *N_MODE, char *outdir,
	      int *PRINT_CONFCHANGE, int *PRINT_FORCE,
	      int *PRINT_PDB, int *PRINT_MODE_SUMM,
	      char **FILE_FORCE, int *ALLOSTERY,
	      float *KAPPA, int *FIT_B,
	      float *RMSD_MIN, int *NMUT,
	      struct Para_simul *Para_simul,
	      struct Para_confchange *Para_confchange,
	      float *SEQID_THR,
	      int *PRINT_COV_COUPLING,
	      int *PRINT_DEF_COUPLING,
	      int *PRINT_DIR_COUPLING,
	      int *PRINT_COORD_COUPLING,
	      int *PRINT_SIGMA_DIJ,
	      char *PROF_TYPE,
	      int *ALL_PAIRS, float *SIGMA,
	      int *STRAIN, char *SITES, int *PRINT_CMAT,
	      int *FORCE_STAB)
{
  FILE *file_in=fopen(filename, "r");
  if(file_in==NULL){
    printf("ERROR, TNM input file %s not found\n", filename); 
    return(0);
  }
  char string[1000], dumm[80];
  printf("Reading parameters in %s\n", filename);
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if(string[0]=='#')continue;
    if(strncmp(string, "PDB1", 4)==0){
      sscanf(string+5, "%s", file_pdb1);
    }else if(strncmp(string, "CH1",3 )==0){
      sscanf(string+4, "%s", dumm);
      if((strncmp(dumm,"ALL", 3)==0)||(strncmp(dumm,"all", 3)==0)){
	*chain1='*';
      }else{
	strcpy(chain1,dumm);
      }
    }else if(strncmp(string, "PDB2", 4)==0){
      sscanf(string+5, "%s", file_pdb2);
    }else if(strncmp(string, "CH2",3 )==0){
      sscanf(string+4, "%s", dumm);
      if((strncmp(dumm,"ALL", 3)==0)||(strncmp(dumm,"all", 3)==0)){
	*chain2='*';
      }else{
	strcpy(chain2,dumm);
      }
    }else if(strncmp(string, "DOF", 3)==0){
      sscanf(string+4, "%s", dumm);
      if(strncmp(dumm, "CART", 4)==0){*ANM=1;}
      else if(strncmp(dumm, "TORS", 4)!=0){
	printf("WARNING, not allowed degrees of freedom: %s\n", dumm);
      }
    }else if(strncmp(string, "REF", 3)==0){
      sscanf(string+4, "%s", REF);
    }else if(strncmp(string, "SIDECHAIN", 9)==0){
      sscanf(string+10, "%d", SIDECHAINS);
    }else if(strncmp(string, "MIN_INT", 7)==0){
      sscanf(string+8, "%d", MIN_INT);
    }else if(strncmp(string, "E_MIN", 5)==0){
      sscanf(string+6, "%f", E_MIN);
    }else if(strncmp(string, "COLL_THR", 8)==0){
      sscanf(string+9, "%f", COLL_THR);
      printf("COLL_THR= %.1f\n", *COLL_THR); *COLL_THR*=3;
    }else if(strncmp(string, "PSI", 3)==0){
      sscanf(string+4, "%d", PSI);
      if(*PSI==0)printf("Psi angle frozen\n");
    }else if(strncmp(string, "OMEGA", 5)==0){
      sscanf(string+6, "%d", OMEGA);
      if(*OMEGA)printf("Omega angle used as degree of freedom\n");
      if(*OMEGA<0)
	printf("Omega angle is dof if Domega>%d degrees.\n", D_omega_thr);
    }else if(strncmp(string, "K_OMEGA", 7)==0){
      sscanf(string+8, "%f", K_OMEGA);
      if(*OMEGA){
	printf("Elastic constant for omega angle: %.3f\n", *K_OMEGA);
      }else if(*K_OMEGA){
	printf("WARNING, elastic constant for omega set but omega is frozen\n");
      }
    }else if(strncmp(string, "K_BA", 4)==0){
      sscanf(string+5, "%f", K_BA);
      printf("Elastic constant for bond angles: %.2f\n", *K_BA);
    }else if(strncmp(string, "K_BL", 4)==0){
      sscanf(string+5, "%f", K_BL);
      printf("Elastic constant for bond lengths: %.2f\n", *K_BL);
    }else if(strncmp(string, "K_PSI", 5)==0){
      sscanf(string+6, "%f", K_PSI);
      if(*K_PSI)printf("Elastic constant for psi angle:    %.3f\n", *K_PSI);
    }else if(strncmp(string, "K_PHI", 5)==0){
      sscanf(string+6, "%f", K_PHI);
      if(*K_PHI)printf("Elastic constant for phi angle:    %.3f\n", *K_PHI);
    }else if(strncmp(string, "K_CHI", 5)==0){
      sscanf(string+6, "%f", K_CHI);
      if(*K_PHI)printf("Elastic constant for chi angle:    %.3f\n", *K_CHI);
    }else if(strncmp(string, "CONT_TYPE", 9)==0){
      sscanf(string+10, "%s", INT_TYPE);
      if(strncmp(INT_TYPE, "HNM", 3)==0)*ANM=1;
    }else if(strncmp(string, "CONT_THR", 8)==0){
      sscanf(string+ 9, "%f", C_THR);
    }else if(strncmp(string, "S_THR", 5)==0){
      sscanf(string+6, "%f", S_THR);
    }else if(strncmp(string, "S_TYPE", 6)==0){
      sscanf(string+7, "%d", S_TYPE);
    }else if(strncmp(string, "ONEINT", 6)==0){
      sscanf(string+7, "%d", ONEINT);
    }else if(strncmp(string, "N_RESRES", 8)==0){
      sscanf(string+9, "%d", N_RESRES);
      if(*N_RESRES <1){
	printf("WARNING, not allowed value of N_RESRES: %d\n", *N_RESRES);
	printf("Setting to default value 1\n"); *N_RESRES=1;
      }
    }else if(strncmp(string, "EXP_HESSIAN", 11)==0){
      sscanf(string+12, "%f", &EXP_HESSIAN);
    }else if(strncmp(string, "KAPPA", 8)==0){
      sscanf(string+9, "%f",  KAPPA);
    }else if(strncmp(string, "FIT_B", 5)==0){
      sscanf(string+6, "%d",  FIT_B);
    }else if(strncmp(string, "RMSD_MIN", 8)==0){
      sscanf(string+9, "%f",  RMSD_MIN);
    }else if(strncmp(string, "NMUT", 4)==0){
      sscanf(string+5, "%d",  NMUT);
    }else if(strncmp(string, "MUT_FORCE", 9)==0){
      sscanf(string+10, "%d", FORCE_STAB);
    }else if(strncmp(string, "RMSD_THR", 8)==0){
      sscanf(string+9, "%f",  &(Para_confchange->RMSD_THR));
    }else if(strncmp(string, "SEQID_THR", 9)==0){
      sscanf(string+10, "%f", SEQID_THR);
    }else if(strncmp(string, "DEBUG", 5)==0){
      sscanf(string+6, "%d", &DEBUG);
    }else if(strncmp(string, "FILE_FORCE", 10)==0){
      *FILE_FORCE=malloc(400*sizeof(char));
      sscanf(string+11, "%s", *FILE_FORCE);
    }else if(strncmp(string, "SIMUL", 5)==0){
      sscanf(string+6, "%d", &(Para_simul->N_SIMUL));
    }else if(strncmp(string, "STEP_MAX", 8)==0){
      sscanf(string+9, "%f", &(Para_simul->STEP_MAX));
    }else if(strncmp(string, "STEP_MIN", 8)==0){
      sscanf(string+9, "%f", &(Para_simul->STEP_MIN));
    }else if(strncmp(string, "NSTEPS", 6)==0){
      sscanf(string+7, "%d", &(Para_simul->NSTEPS));
    }else if(strncmp(string, "ANGLE", 5)==0){
      sscanf(string+6, "%f", &(Para_simul->ANGLE));
    }else if(strncmp(string, "OUTDIR", 6)==0){
      sscanf(string+7, "%s", outdir);
    }else if(strncmp(string, "NMODES", 6)==0){
      sscanf(string+7, "%d", N_MODE);
    }else if(strncmp(string, "PRINT_PDB", 9)==0){
      sscanf(string+10, "%d", PRINT_PDB);
    }else if(strncmp(string, "PRINT_CHANGE", 12)==0){
      sscanf(string+13, "%d", PRINT_CONFCHANGE);
    }else if(strncmp(string, "PRINT_FORCE", 11)==0){
      sscanf(string+12, "%d", PRINT_FORCE);
    }else if(strncmp(string, "PRINT_SUMM", 10)==0){
      sscanf(string+11, "%d", PRINT_MODE_SUMM);
    }else if(strncmp(string, "ALLOSTERY", 9)==0){
      sscanf(string+10, "%d", ALLOSTERY);
    }else if(strncmp(string, "SITES", 5)==0){
      sscanf(string+6,  "%s", SITES);
    }else if(strncmp(string, "PRINT_COV_COUPLING", 18)==0){
      sscanf(string+19, "%d", PRINT_COV_COUPLING);
    }else if(strncmp(string, "PRINT_DEF_COUPLING", 18)==0){
      sscanf(string+19, "%d", PRINT_DEF_COUPLING);
    }else if(strncmp(string, "PRINT_DIR_COUPLING", 18)==0){
      sscanf(string+19, "%d", PRINT_DIR_COUPLING);
    }else if(strncmp(string, "PRINT_COORD_COUPLING", 20)==0){
      sscanf(string+21, "%d", PRINT_COORD_COUPLING);
    }else if(strncmp(string, "PRINT_SIGMA_DIJ", 15)==0){
      sscanf(string+16, "%d", PRINT_SIGMA_DIJ);
    }else if(strncmp(string, "PRINT_CONT_MAT", 14)==0){
      sscanf(string+15, "%d", PRINT_CMAT);
    }else if(strncmp(string, "PROF_TYPE", 9)==0){
      sscanf(string+10, "%s", dumm);
      if((dumm[0]=='A')||(dumm[0]=='C')||(dumm[0]=='P')){
	*PROF_TYPE=dumm[0];
      }else{
	printf("WARNING, profile type %s does not exist\n", dumm);
      }
    }else if(strncmp(string, "ALL_PAIRS", 9)==0){
      sscanf(string+10, "%d", ALL_PAIRS);
    }else if(strncmp(string, "SIGMA", 5)==0){
      sscanf(string+6, "%f", SIGMA);
    }else if(strncmp(string, "STRAIN", 6)==0){
      sscanf(string+7, "%d", STRAIN);
    }else if(strncmp(string, "AMPLITUDE", 9)==0){
      sscanf(string+10, "%f", &(Para_simul->AMPLITUDE));
    }else if(strncmp(string, "E_THR", 5)==0){
      sscanf(string+6, "%f", &(Para_simul->E_THR));
    }else if(strncmp(string, "D_REP", 5)==0){
      sscanf(string+6, "%f", &(Para_simul->D_REP));
    }else if(strncmp(string, "PDB_STEP", 8)==0){
      sscanf(string+9, "%f", &(Para_simul->PDB_STEP));

      //}else if(strncmp(string, "", )==0){
    }else if(string[0]!='\n'){
      printf("WARNING, unrecognized line:\n%s", string);
    }
  }
  fclose(file_in);
  if((*K_PHI==0)&&(*K_PSI))*K_PHI=*K_PSI;
  if((*K_PSI==0)&&(*K_PHI))*K_PSI=*K_PHI;
  if((*K_CHI==0)&&(*K_PHI))*K_CHI=*K_PHI;
  if((*S_TYPE < 0)||(*S_TYPE >2)){
    printf("WARNING, not allowed Shadow interaction type %d\n", *S_TYPE);
    *S_TYPE=0;
    printf("Setting to default %d (angle kij, d_ij<d_ik<d_jk)\n", *S_TYPE);
  }
  if(strncmp(INT_TYPE, "SHA", 3)==0){
    if(*S_TYPE==0){ // Thereshold on cosine(kij)
      if((*S_THR<0)||(*S_THR>1)){
	printf("ERROR Shadow type %d, shadow parameter %f out of range. ",
	       *S_TYPE, *S_THR); exit(8);
      }
    }else if (*S_TYPE==1){ // Threshold on distance from axis
      if(*S_THR<0){
	printf("ERROR Shadow type %d, shadow parameter %f out of range. ",
	       *S_TYPE, *S_THR); exit(8);
      }
    }else if (*S_TYPE==2){ // Atom radius
      if(*S_THR<0){
	printf("ERROR Shadow type %d, shadow parameter %f out of range. ",
	       *S_TYPE, *S_THR); exit(8);
      }
    }
  }
  return(1);
}

int Relevant_modes(float *omega2, int *select, int N, float N_atoms)
{
  double sum=0; int i;
  for(i=0; i<N; i++)if(select[i])sum+=1./omega2[i];
  float eps; if(N_atoms>100){eps=1./N_atoms;}else{eps=1./100;}
  float thr=sum*(1.-eps); sum=0;
  for(i=0; i<N; i++){
    if(select[i])sum+=1./omega2[i];
    if(sum>thr)break;
  }
  return(i);
}

